"""Chuyển infinite_grass_block.glb -> assets/grass.bin + assets/grass.png
Định dạng grass.bin (little-endian):
  magic 'GRS2', int nVerts, int nIdx, int nBlades, int nSamples
  nVerts * 9 float : pos(3) uv(2) morphDelta(3) bladeIndex(1)
  nIdx * uint16    : indices
  nBlades * nSamples float : trọng số morph "wind" của từng lá cỏ (animation 12s, lặp vòng)
"""
import struct, json, sys
import numpy as np

src = sys.argv[1] if len(sys.argv) > 1 else "model/infinite_grass_block_ultra__2_.glb"
out = sys.argv[2] if len(sys.argv) > 2 else "app/src/main/assets"

d = open(src, 'rb').read()
jl = struct.unpack('<I', d[12:16])[0]
j = json.loads(d[20:20 + jl]); bin_ = d[20 + jl + 8:]

def acc(i):
    A = j['accessors'][i]; bv = j['bufferViews'][A['bufferView']]
    nc = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4}[A['type']]
    dt = {5126: '<f4', 5123: '<u2', 5125: '<u4'}[A['componentType']]
    return np.frombuffer(bin_, dt, A['count'] * nc, bv['byteOffset'] + A.get('byteOffset', 0)).reshape(A['count'], nc)

# animation: node -> weights output accessor
wmap = {}
anim = j['animations'][0]
for ch in anim['channels']:
    wmap[ch['target']['node']] = anim['samplers'][ch['sampler']]['output']

verts, idx, weights, base = [], [], [], 0
for ni, node in enumerate(j['nodes']):
    prim = j['meshes'][node['mesh']]['primitives'][0]
    pos = acc(prim['attributes']['POSITION']).astype(np.float32)
    uv = acc(prim['attributes']['TEXCOORD_0']).astype(np.float32)
    mor = acc(prim['targets'][0]['POSITION']).astype(np.float32)
    w = acc(wmap[ni]).ravel().astype(np.float32)[:-1]   # mẫu cuối trùng mẫu đầu
    weights.append(w)
    bl = np.full((len(pos), 1), ni, np.float32)
    verts.append(np.hstack([pos, uv, mor, bl]).astype(np.float32))
    idx.append(acc(prim['indices']).ravel().astype(np.uint16) + base)
    base += len(pos)

V = np.vstack(verts); I = np.concatenate(idx); W = np.stack(weights)
assert base < 65536
with open(out + "/grass.bin", 'wb') as f:
    f.write(b'GRS2'); f.write(struct.pack('<IIII', len(V), len(I), W.shape[0], W.shape[1]))
    f.write(V.astype('<f4').tobytes()); f.write(I.astype('<u2').tobytes()); f.write(W.astype('<f4').tobytes())
img = j['images'][0]; bv = j['bufferViews'][img['bufferView']]
open(out + "/grass.png", 'wb').write(bin_[bv['byteOffset']:bv['byteOffset'] + bv['byteLength']])
print("verts", len(V), "idx", len(I), "weights", W.shape, "size", 20 + V.nbytes + I.nbytes + W.nbytes)
