package com.example.greenfield;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.MotionEvent;
import android.view.View;

/** Nút nhảy hình tròn: giữ để nhảy liên tục. */
public class JumpView extends View {
    public interface Listener {
        void onJump(boolean held);
    }

    private final float density = getResources().getDisplayMetrics().density;
    private final float size = 76f * density;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arrow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path tri = new Path();
    private boolean pressed = false;
    private Listener listener;

    public JumpView(Context context) {
        super(context);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(2f * density);
        stroke.setColor(0x99FFFFFF);
        arrow.setColor(0xDDFFFFFF);
        float r = size * 0.2f;
        tri.moveTo(0, -r);
        tri.lineTo(r, r * 0.8f);
        tri.lineTo(-r, r * 0.8f);
        tri.close();
    }

    public void setListener(Listener l) {
        listener = l;
    }

    @Override
    protected void onMeasure(int w, int h) {
        setMeasuredDimension((int) size, (int) size);
    }

    @Override
    protected void onDraw(Canvas c) {
        float cx = size / 2f, cy = size / 2f, r = size / 2f - 4f * density;
        fill.setColor(pressed ? 0x99FFFFFF : 0x44FFFFFF);
        c.drawCircle(cx, cy, r, fill);
        c.drawCircle(cx, cy, r, stroke);
        c.save();
        c.translate(cx, cy);
        c.drawPath(tri, arrow);
        c.restore();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                set(true);
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                set(false);
                break;
        }
        return true;
    }

    private void set(boolean p) {
        if (pressed == p) return;
        pressed = p;
        if (listener != null) listener.onJump(p);
        invalidate();
    }
}
