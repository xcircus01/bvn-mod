# Grass Wind Shader - Bedrock 26.0

Workflow tự tải shaderc, material vanilla và source RenderChunk. Quy trình:

1. **Chạy lần 1** (Actions -> Run workflow). Nó build bản vanilla để kiểm tra chuỗi công cụ,
   và xuất artifact `RenderChunk-shaders` (chứa vertex.sc, fragment.sc, varying.def.sc, bgfx_shader.sh).
2. Tải artifact đó, sửa `vertex.sc`:
   ```glsl
   #include "grass_wind.sh"            // sau các #include khác
   // sau khi có worldPos tuyệt đối, trước khi nhân View/Proj:
   float gy = fract(a_position.y + 0.002) - 0.002;
   worldPos.xyz += grassWindDisplace(gy, <giây>, worldPos.xz);
   ```
3. Commit `vertex.sc` (và các file còn lại) vào `project/RenderChunk/shaders/`. **Chạy lại**: workflow dùng file của bạn.

Nếu tải tự động lỗi, xem log: workflow in ra danh sách release/file có sẵn. Các biến chỉnh ở đầu build.yml.
Bạn cũng có thể tự đặt `vanilla/<platform>/RenderChunk.material.json` (bằng `lazurite serialize`), workflow sẽ dùng thay vì tải.
