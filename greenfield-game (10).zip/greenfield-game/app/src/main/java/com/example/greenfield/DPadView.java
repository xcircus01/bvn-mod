package com.example.greenfield;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

/**
 * Bàn phím 3x3: 4 nút tiến/lùi/trái/phải + 4 nút góc (chéo). Ô giữa để trống.
 * Hỗ trợ nhiều ngón và trượt giữa các nút.
 */
public class DPadView extends View {
    public interface Listener {
        /** strafe: -1 trái .. +1 phải; forward: -1 lùi .. +1 tiến */
        void onMove(float strafe, float forward);
    }

    public interface SneakListener {
        void onSneak(boolean sneaking);
    }

    public interface SprintListener {
        void onSprint(boolean sprinting);
    }

    private static final long DOUBLE_TAP_MS = 300;

    private final float density = getResources().getDisplayMetrics().density;
    private final float cell = 54f * density;
    private final boolean[][] pressed = new boolean[3][3]; // [row][col]
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arrow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final Path tri = new Path();
    private Listener listener;
    private SneakListener sneakListener;
    private SprintListener sprintListener;
    private long lastForwardTap = -10000;   // lần chạm gần nhất vào hàng nút tiến (hàng trên)
    private boolean sprintArmed = false, sprinting = false;
    private boolean sneaking = false;
    private final Paint chevron = new Paint(Paint.ANTI_ALIAS_FLAG);

    public DPadView(Context context) {
        super(context);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(2f * density);
        stroke.setColor(0x99FFFFFF);
        arrow.setColor(0xDDFFFFFF);
        chevron.setStyle(Paint.Style.STROKE);
        chevron.setStrokeWidth(3.5f * density);
        chevron.setStrokeCap(Paint.Cap.ROUND);
        chevron.setStrokeJoin(Paint.Join.ROUND);
        chevron.setColor(0xDDFFFFFF);
        float r = cell * 0.2f;
        tri.moveTo(0, -r);
        tri.lineTo(r, r * 0.8f);
        tri.lineTo(-r, r * 0.8f);
        tri.close();
    }

    public void setListener(Listener l) {
        listener = l;
    }

    /** Chạy nhanh kiểu Bedrock: bấm đúp nút tiến (hàng trên) rồi giữ; thả nút tiến thì dừng chạy nhanh. */
    public void setSprintListener(SprintListener l) {
        sprintListener = l;
    }

    public void setSneakListener(SneakListener l) {
        sneakListener = l;
    }

    @Override
    protected void onMeasure(int w, int h) {
        setMeasuredDimension((int) (cell * 3), (int) (cell * 3));
    }

    @Override
    protected void onDraw(Canvas c) {
        float pad = 4f * density;
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                rect.set(col * cell + pad, row * cell + pad, (col + 1) * cell - pad, (row + 1) * cell - pad);
                boolean center = row == 1 && col == 1;
                boolean on = center ? sneaking : pressed[row][col];
                fill.setColor(on ? 0x99FFFFFF : 0x44FFFFFF);
                c.drawRoundRect(rect, 10f * density, 10f * density, fill);
                c.drawRoundRect(rect, 10f * density, 10f * density, stroke);
                if (center) {
                    // nút ngồi: dấu chevron hướng xuống
                    float r = cell * 0.18f, cx = rect.centerX(), cy = rect.centerY();
                    c.drawLine(cx - r, cy - r * 0.4f, cx, cy + r * 0.6f, chevron);
                    c.drawLine(cx, cy + r * 0.6f, cx + r, cy - r * 0.4f, chevron);
                    continue;
                }
                c.save();
                c.translate(rect.centerX(), rect.centerY());
                c.rotate((float) Math.toDegrees(Math.atan2(col - 1, -(row - 1))));
                c.drawPath(tri, arrow);
                c.restore();
            }
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int action = e.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
            int ai = e.getActionIndex();
            if ((int) Math.floor(e.getY(ai) / cell) == 0 && (int) Math.floor(e.getX(ai) / cell) >= 0
                    && (int) Math.floor(e.getX(ai) / cell) <= 2) {
                long t = e.getEventTime();
                if (t - lastForwardTap <= DOUBLE_TAP_MS) {
                    sprintArmed = true;     // bấm đúp nút tiến -> chạy nhanh
                    lastForwardTap = -10000;
                } else {
                    lastForwardTap = t;
                }
            }
            if ((int) Math.floor(e.getX(ai) / cell) == 1 && (int) Math.floor(e.getY(ai) / cell) == 1) {
                sneaking = !sneaking;   // chạm nút giữa: bật/tắt ngồi
                if (sneakListener != null) sneakListener.onSneak(sneaking);
            }
        }
        boolean[][] now = new boolean[3][3];
        if (action != MotionEvent.ACTION_CANCEL) {
            for (int i = 0; i < e.getPointerCount(); i++) {
                boolean lifting = (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP)
                        && i == e.getActionIndex();
                if (lifting) continue;
                int col = (int) Math.floor(e.getX(i) / cell);
                int row = (int) Math.floor(e.getY(i) / cell);
                if (col < 0 || col > 2 || row < 0 || row > 2 || (row == 1 && col == 1)) continue;
                now[row][col] = true;
            }
        }
        float strafe = 0, forward = 0;
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                pressed[row][col] = now[row][col];
                if (now[row][col]) {
                    strafe += col - 1;
                    forward += 1 - row;
                }
            }
        }
        strafe = Math.max(-1f, Math.min(1f, strafe));
        forward = Math.max(-1f, Math.min(1f, forward));
        if (forward <= 0f) sprintArmed = false;   // thả nút tiến -> hết chạy nhanh
        boolean sp = sprintArmed && forward > 0f;
        if (sp != sprinting) {
            sprinting = sp;
            if (sprintListener != null) sprintListener.onSprint(sp);
        }
        if (listener != null) listener.onMove(strafe, forward);
        invalidate();
        return true;
    }
}
