package com.example.greenfield;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private GameView gameView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FrameLayout root = new FrameLayout(this);
        gameView = new GameView(this);
        root.addView(gameView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        DPadView pad = new DPadView(this);
        pad.setListener(gameView::setMove);
        int m = (int) (24 * getResources().getDisplayMetrics().density);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.START);
        lp.setMargins(m, 0, 0, m);
        root.addView(pad, lp);
        pad.setSneakListener(gameView::setSneak);
        pad.setSprintListener(gameView::setSprint);

        JumpView jump = new JumpView(this);
        jump.setListener(new JumpView.Listener() {
            @Override public void onJump(boolean held) { gameView.setJump(held); }
            @Override public void onDescend(boolean held) { gameView.setDescend(held); }
            @Override public void onFlyToggle(boolean flying) { gameView.setFlying(flying); }
        });
        // hạ cánh chạm đất (từ luồng GL) -> đổi 2 nút lên/xuống về nút nhảy
        gameView.setOnFlyEnd(() -> runOnUiThread(() -> jump.setFlying(false)));
        int jm = (int) (32 * getResources().getDisplayMetrics().density);
        FrameLayout.LayoutParams jp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.END);
        jp.setMargins(0, 0, jm, (int) (8 * getResources().getDisplayMetrics().density)); // view cao 3 ô (lên/nhảy/xuống), nút nhảy ở giữa
        root.addView(jump, jp);

        // nút đổi map (góc trên bên phải): Cỏ <-> Phẳng
        float d = getResources().getDisplayMetrics().density;
        TextView mapBtn = new TextView(this);
        mapBtn.setTextColor(Color.WHITE);
        mapBtn.setTextSize(14f);
        mapBtn.setPadding((int) (14 * d), (int) (8 * d), (int) (14 * d), (int) (8 * d));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0x88000000);
        bg.setStroke((int) (2 * d), 0x99FFFFFF);
        bg.setCornerRadius(10 * d);
        mapBtn.setBackground(bg);
        mapBtn.setText("Map: Cỏ");
        final boolean[] flat = {false};
        mapBtn.setOnClickListener(v -> {
            flat[0] = !flat[0];
            mapBtn.setText(flat[0] ? "Map: Phẳng" : "Map: Cỏ");
            gameView.setFlatMap(flat[0]);
        });
        FrameLayout.LayoutParams mp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.END);
        mp.setMargins(0, (int) (16 * d), (int) (16 * d), 0);
        root.addView(mapBtn, mp);
        setContentView(root);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        gameView.resume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        gameView.pause();
    }
}
