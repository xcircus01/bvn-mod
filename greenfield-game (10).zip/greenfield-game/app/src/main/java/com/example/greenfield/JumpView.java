package com.example.greenfield;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.MotionEvent;
import android.view.View;

/**
 * Nút nhảy hình tròn (giống Minecraft Bedrock).
 *  - Luôn có nút nhảy ở giữa. Giữ để nhảy liên tục.
 *  - Bấm ĐÚP nhanh (<= 300ms) nút nhảy để BẬT bay; bấm đúp lần nữa để TẮT bay.
 *  - Khi đang bay, nút LÊN hiện ngay trên nút nhảy, nút XUỐNG hiện ngay dưới nút nhảy (nút nhảy vẫn còn
 *    và khi bay thì cũng bay lên). Chạm đất bằng nút xuống cũng tự tắt bay.
 *
 * View luôn cao 3 ô (lên / nhảy / xuống) nên bố cục không xê dịch khi đổi chế độ. Khi không bay, hai ô
 * lên/xuống không nhận chạm (trả false cho ACTION_DOWN) nên kéo xoay camera ở đó vẫn hoạt động.
 */
public class JumpView extends View {
    public interface Listener {
        /** Nút nhảy (mặt đất) hoặc nút lên / nút nhảy (đang bay). */
        void onJump(boolean held);

        /** Đang bay: nút XUỐNG. */
        void onDescend(boolean held);

        /** Người chơi bấm đúp để bật/tắt bay. */
        void onFlyToggle(boolean flying);
    }

    private static final long DOUBLE_TAP_MS = 300;

    private final float density = getResources().getDisplayMetrics().density;
    private final float size = 76f * density;      // nút nhảy
    private final float fs = 56f * density;        // nút lên / xuống (nhỏ hơn)
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arrow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path tri = new Path();
    private boolean flying = false, upPressed = false, downPressed = false;
    private long lastTapTime = -10000;
    private int ignoredId = -1;          // ngón vừa bấm đúp: bỏ qua đến khi nhấc lên
    private boolean ignoreAll = false;   // vừa hạ cánh khi ngón còn giữ: bỏ qua đến lần chạm mới
    private Listener listener;

    public JumpView(Context context) {
        super(context);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(2f * density);
        stroke.setColor(0x99FFFFFF);
        arrow.setColor(0xDDFFFFFF);
        float r = size * 0.2f;
        tri.moveTo(0, -r);
        tri.lineTo(r, r * 0.8f);
        tri.lineTo(-r, r * 0.8f);
        tri.close();
    }

    public void setListener(Listener l) {
        listener = l;
    }

    /** Gọi từ luồng UI khi trạng thái bay bị đổi từ bên ngoài (hạ cánh chạm đất, đổi map). */
    public void setFlying(boolean on) {
        if (flying == on) return;
        flying = on;
        setPressedState(false, false);
        ignoreAll = true;
        invalidate();
    }

    @Override
    protected void onMeasure(int w, int h) {
        setMeasuredDimension((int) size, (int) (size + 2f * fs));
    }

    @Override
    protected void onDraw(Canvas c) {
        float cx = size / 2f;
        if (flying) {
            drawButton(c, cx, fs / 2f, fs, upPressed, 0f);                   // lên (trên nút nhảy)
            drawButton(c, cx, fs + size + fs / 2f, fs, downPressed, 180f);   // xuống (dưới nút nhảy)
        }
        drawButton(c, cx, fs + size / 2f, size, upPressed, 0f);              // nút nhảy (luôn có)
    }

    private void drawButton(Canvas c, float cx, float cy, float cell, boolean on, float rotate) {
        float r = cell / 2f - 4f * density;
        fill.setColor(on ? 0x99FFFFFF : 0x44FFFFFF);
        c.drawCircle(cx, cy, r, fill);
        c.drawCircle(cx, cy, r, stroke);
        c.save();
        c.translate(cx, cy);
        c.rotate(rotate);
        float k = cell / size;
        c.scale(k, k);
        c.drawPath(tri, arrow);
        c.restore();
    }

    /** 0 = ô trên (nút lên), 1 = nút nhảy, 2 = ô dưới (nút xuống). */
    private int zone(float y) {
        if (y < fs) return 0;
        if (y < fs + size) return 1;
        return 2;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN) {
            ignoredId = -1;
            ignoreAll = false;
            // không bay: chỉ nút nhảy nhận chạm, còn lại nhường cho GameView (xoay camera)
            if (!flying && zone(e.getY()) != 1) return false;
        }
        if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_POINTER_DOWN) {
            int ai = e.getActionIndex();
            if (zone(e.getY(ai)) == 1) {   // bấm đúp nút nhảy: bật/tắt bay
                long now = e.getEventTime();
                if (now - lastTapTime <= DOUBLE_TAP_MS) {
                    lastTapTime = -10000;
                    ignoredId = e.getPointerId(ai);
                    toggleFly();
                } else {
                    lastTapTime = now;
                }
            }
        }

        boolean up = false, down = false;
        if (a != MotionEvent.ACTION_CANCEL && !ignoreAll) {
            for (int i = 0; i < e.getPointerCount(); i++) {
                if (e.getPointerId(i) == ignoredId) continue;
                if ((a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_POINTER_UP) && i == e.getActionIndex()) continue;
                int z = zone(e.getY(i));
                if (!flying) {
                    if (z == 1) up = true;
                } else if (z == 2) {
                    down = true;
                } else {
                    up = true;   // nút lên hoặc nút nhảy: đều bay lên
                }
            }
        }
        if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
            ignoredId = -1;
        } else if (a == MotionEvent.ACTION_POINTER_UP && e.getPointerId(e.getActionIndex()) == ignoredId) {
            ignoredId = -1;
        }
        setPressedState(up, down);
        return true;
    }

    private void toggleFly() {
        flying = !flying;
        setPressedState(false, false);
        if (listener != null) listener.onFlyToggle(flying);
        invalidate();
    }

    private void setPressedState(boolean up, boolean down) {
        if (up != upPressed) {
            upPressed = up;
            if (listener != null) listener.onJump(up);
            invalidate();
        }
        if (down != downPressed) {
            downPressed = down;
            if (listener != null) listener.onDescend(down);
            invalidate();
        }
    }
}
