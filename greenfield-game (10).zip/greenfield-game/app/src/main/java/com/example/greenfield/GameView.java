package com.example.greenfield;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.view.MotionEvent;

/** Kéo 1 ngón trên màn hình để xoay camera. Di chuyển dùng DPadView. */
public class GameView extends GLSurfaceView {
    private final GrassRenderer renderer;
    private float lastX, lastY;
    private int activeId = -1;

    public GameView(Context context) {
        super(context);
        setEGLContextClientVersion(3);
        setEGLConfigChooser(8, 8, 8, 8, 24, 0);
        renderer = new GrassRenderer(context);
        setRenderer(renderer);
        setRenderMode(RENDERMODE_CONTINUOUSLY);
    }

    public void setMove(float strafe, float forward) {
        renderer.setMove(strafe, forward);
    }

    public void setSprint(boolean on) {
        renderer.setSprint(on);
    }

    public void setSneak(boolean on) {
        renderer.setSneak(on);
    }

    public void setJump(boolean held) {
        renderer.setJump(held);
    }

    public void setFlatMap(boolean flat) {
        renderer.setFlatMap(flat);
    }

    public void setFlying(boolean on) {
        renderer.setFlying(on);
    }

    public void setDescend(boolean held) {
        renderer.setDescend(held);
    }

    public void setOnFlyEnd(Runnable r) {
        renderer.setOnFlyEnd(r);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                activeId = e.getPointerId(0);
                lastX = e.getX();
                lastY = e.getY();
                break;
            case MotionEvent.ACTION_MOVE: {
                int i = e.findPointerIndex(activeId);
                if (i < 0) break;
                renderer.look(e.getX(i) - lastX, e.getY(i) - lastY);
                lastX = e.getX(i);
                lastY = e.getY(i);
                break;
            }
            case MotionEvent.ACTION_POINTER_UP: {
                if (e.getPointerId(e.getActionIndex()) == activeId) {
                    int j = e.getActionIndex() == 0 ? 1 : 0;
                    activeId = e.getPointerId(j);
                    lastX = e.getX(j);
                    lastY = e.getY(j);
                }
                break;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                activeId = -1;
                break;
        }
        return true;
    }

    public void resume() { onResume(); }

    public void pause() { onPause(); }
}
