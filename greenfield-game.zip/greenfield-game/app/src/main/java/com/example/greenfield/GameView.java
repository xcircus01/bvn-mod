package com.example.greenfield;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.view.MotionEvent;

public class GameView extends GLSurfaceView {
    private final GrassRenderer renderer;
    private float lastX, lastY;

    public GameView(Context context) {
        super(context);
        setEGLContextClientVersion(3);
        setEGLConfigChooser(8, 8, 8, 8, 16, 0);
        renderer = new GrassRenderer(context);
        setRenderer(renderer);
        setRenderMode(RENDERMODE_CONTINUOUSLY);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                lastX = e.getX();
                lastY = e.getY();
                break;
            case MotionEvent.ACTION_MOVE:
                renderer.pan(e.getX() - lastX, e.getY() - lastY);
                lastX = e.getX();
                lastY = e.getY();
                break;
        }
        return true;
    }

    public void resume() { onResume(); }

    public void pause() { onPause(); }
}
