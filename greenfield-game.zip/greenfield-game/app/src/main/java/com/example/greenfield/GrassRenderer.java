package com.example.greenfield;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLES30;
import android.opengl.GLSurfaceView;
import android.opengl.GLUtils;
import android.opengl.Matrix;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/**
 * Vẽ nền phẳng xanh lá đậm + cỏ từ model infinite_grass_block (1x1 đơn vị, giống 1 block Minecraft).
 * Block cỏ được lát (tile) vô hạn quanh camera bằng instancing, mỗi ô xoay/cao thấp khác nhau,
 * cỏ "mọc" lên lúc khởi động và đung đưa theo animation wind_sway của GLB.
 */
public class GrassRenderer implements GLSurfaceView.Renderer {
    private static final int GRID = 21;            // số ô cỏ mỗi chiều quanh camera
    private static final int STRIDE = 9 * 4;       // pos3 uv2 morph3 blade1

    // Nền xanh lá đậm
    private static final float GR = 11f / 255f, GG = 61f / 255f, GB = 11f / 255f;

    private static final String VS =
            "#version 300 es\n" +
            "uniform mat4 uVP;\n" +
            "uniform vec3 uEye;\n" +
            "uniform vec2 uOrigin;\n" +
            "uniform float uGrid;\n" +
            "uniform float uTime;\n" +      // 0..12 giây (lặp)
            "uniform float uGrow;\n" +      // thời gian từ lúc khởi động (tối đa 10)
            "uniform highp sampler2D uWind;\n" +
            "layout(location=0) in vec3 aPos;\n" +
            "layout(location=1) in vec2 aUV;\n" +
            "layout(location=2) in vec3 aMorph;\n" +
            "layout(location=3) in float aBlade;\n" +
            "out vec2 vUV;\n" +
            "out float vFog;\n" +
            "float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }\n" +
            "void main(){\n" +
            "  float id = float(gl_InstanceID);\n" +
            "  vec2 tile = uOrigin + vec2(mod(id, uGrid), floor(id / uGrid));\n" +
            "  float h1 = hash(tile);\n" +
            "  float h2 = hash(tile + 17.3);\n" +
            // sóng gió lan qua các ô
            "  float t = mod(uTime + tile.x * 0.23 + tile.y * 0.37, 12.0);\n" +
            "  float f = t / 12.0 * 360.0;\n" +
            "  int i0 = int(floor(f)) % 360;\n" +
            "  int i1 = (i0 + 1) % 360;\n" +
            "  int b = int(aBlade + 0.5);\n" +
            "  float w = mix(texelFetch(uWind, ivec2(i0, b), 0).r,\n" +
            "                texelFetch(uWind, ivec2(i1, b), 0).r, fract(f));\n" +
            // cỏ mọc dần, mỗi ô lệch nhịp
            "  float g = clamp((uGrow - h2 * 3.0) / 1.8, 0.0, 1.0);\n" +
            "  g = g * g * (3.0 - 2.0 * g);\n" +
            "  float hs = (0.8 + 0.4 * h1) * g;\n" +
            "  vec3 p = aPos + aMorph * w;\n" +
            "  p.y *= hs;\n" +
            // xoay ô theo bội số 90 độ quanh tâm ô
            "  float ang = floor(h1 * 4.0) * 1.5707963;\n" +
            "  float c = cos(ang), s = sin(ang);\n" +
            "  vec2 q = p.xz - 0.5;\n" +
            "  q = vec2(c * q.x - s * q.y, s * q.x + c * q.y) + 0.5;\n" +
            "  vec3 world = vec3(tile.x + q.x, p.y, tile.y + q.y);\n" +
            "  vUV = aUV;\n" +
            "  vFog = clamp((distance(world, uEye) - 5.0) / 5.0, 0.0, 1.0);\n" +
            "  gl_Position = uVP * vec4(world, 1.0);\n" +
            "}\n";

    private static final String FS =
            "#version 300 es\n" +
            "precision mediump float;\n" +
            "uniform sampler2D uTex;\n" +
            "uniform vec3 uFogColor;\n" +
            "in vec2 vUV;\n" +
            "in float vFog;\n" +
            "out vec4 outColor;\n" +
            "void main(){\n" +
            "  vec3 c = texture(uTex, vUV).rgb;\n" +
            "  outColor = vec4(mix(c, uFogColor, vFog), 1.0);\n" +
            "}\n";

    private final Context context;
    private int program, vao, indexCount, grassTex, windTex;
    private int uVP, uEye, uOrigin, uGrid, uTime, uGrow, uWind, uTex, uFogColor;
    private final float[] proj = new float[16];
    private final float[] view = new float[16];
    private final float[] vp = new float[16];
    private float aspect = 1f;
    private long startNs;

    // Vị trí camera nhìn vào (kéo tay để di chuyển)
    private volatile float targetX = 0f, targetZ = 0f;

    public GrassRenderer(Context context) {
        this.context = context.getApplicationContext();
    }

    /** dx, dy tính bằng pixel khi kéo màn hình. */
    public void pan(float dx, float dy) {
        targetX -= dx * 0.012f;
        targetZ -= dy * 0.012f;
    }

    @Override
    public void onSurfaceCreated(GL10 unused, EGLConfig config) {
        GLES30.glClearColor(GR, GG, GB, 1f);
        GLES30.glEnable(GLES30.GL_DEPTH_TEST);
        GLES30.glDisable(GLES30.GL_CULL_FACE); // lá cỏ hai mặt (doubleSided)

        program = link(compile(GLES30.GL_VERTEX_SHADER, VS), compile(GLES30.GL_FRAGMENT_SHADER, FS));
        uVP = GLES30.glGetUniformLocation(program, "uVP");
        uEye = GLES30.glGetUniformLocation(program, "uEye");
        uOrigin = GLES30.glGetUniformLocation(program, "uOrigin");
        uGrid = GLES30.glGetUniformLocation(program, "uGrid");
        uTime = GLES30.glGetUniformLocation(program, "uTime");
        uGrow = GLES30.glGetUniformLocation(program, "uGrow");
        uWind = GLES30.glGetUniformLocation(program, "uWind");
        uTex = GLES30.glGetUniformLocation(program, "uTex");
        uFogColor = GLES30.glGetUniformLocation(program, "uFogColor");

        loadMesh();
        grassTex = loadGrassTexture();
        startNs = System.nanoTime();
    }

    @Override
    public void onSurfaceChanged(GL10 unused, int width, int height) {
        GLES30.glViewport(0, 0, width, height);
        aspect = (float) width / Math.max(1, height);
    }

    @Override
    public void onDrawFrame(GL10 unused) {
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT | GLES30.GL_DEPTH_BUFFER_BIT);

        float tx = targetX, tz = targetZ;
        float ex = tx, ey = 5f, ez = tz + 6f;
        Matrix.perspectiveM(proj, 0, 60f, aspect, 0.1f, 40f);
        Matrix.setLookAtM(view, 0, ex, ey, ez, tx, 0f, tz, 0f, 1f, 0f);
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0);

        float elapsed = (System.nanoTime() - startNs) / 1e9f;

        GLES30.glUseProgram(program);
        GLES30.glUniformMatrix4fv(uVP, 1, false, vp, 0);
        GLES30.glUniform3f(uEye, ex, ey, ez);
        GLES30.glUniform2f(uOrigin, (float) Math.floor(tx) - GRID / 2, (float) Math.floor(tz) - GRID / 2);
        GLES30.glUniform1f(uGrid, GRID);
        GLES30.glUniform1f(uTime, elapsed % 12f);
        GLES30.glUniform1f(uGrow, Math.min(elapsed, 10f));
        GLES30.glUniform3f(uFogColor, GR, GG, GB);

        GLES30.glActiveTexture(GLES30.GL_TEXTURE0);
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, grassTex);
        GLES30.glUniform1i(uTex, 0);
        GLES30.glActiveTexture(GLES30.GL_TEXTURE1);
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, windTex);
        GLES30.glUniform1i(uWind, 1);

        GLES30.glBindVertexArray(vao);
        GLES30.glDrawElementsInstanced(GLES30.GL_TRIANGLES, indexCount,
                GLES30.GL_UNSIGNED_SHORT, 0, GRID * GRID);
        GLES30.glBindVertexArray(0);
    }

    // ---------- tải model (grass.bin tạo từ GLB bằng tools/convert_glb.py) ----------

    private void loadMesh() {
        try (InputStream in = context.getAssets().open("grass.bin")) {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            byte[] data = bos.toByteArray();

            ByteBuffer head = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
            if (head.getInt(0) != 0x32535247) throw new RuntimeException("grass.bin sai định dạng"); // 'GRS2'
            int nV = head.getInt(4), nI = head.getInt(8), nBlades = head.getInt(12), nSamples = head.getInt(16);
            int off = 20;

            ByteBuffer vb = ByteBuffer.allocateDirect(nV * STRIDE).order(ByteOrder.nativeOrder());
            ByteBuffer ib = ByteBuffer.allocateDirect(nI * 2).order(ByteOrder.nativeOrder());
            ByteBuffer wb = ByteBuffer.allocateDirect(nBlades * nSamples * 4).order(ByteOrder.nativeOrder());
            // Chép từng giá trị theo little-endian để đúng trên mọi máy
            for (int i = 0; i < nV * 9; i++) vb.putFloat(head.getFloat(off + i * 4));
            off += nV * STRIDE;
            for (int i = 0; i < nI; i++) ib.putShort(head.getShort(off + i * 2));
            off += nI * 2;
            for (int i = 0; i < nBlades * nSamples; i++) wb.putFloat(head.getFloat(off + i * 4));
            vb.position(0); ib.position(0); wb.position(0);
            indexCount = nI;

            int[] a = new int[3];
            GLES30.glGenVertexArrays(1, a, 0);
            vao = a[0];
            GLES30.glBindVertexArray(vao);
            GLES30.glGenBuffers(2, a, 1);
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, a[1]);
            GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, nV * STRIDE, vb, GLES30.GL_STATIC_DRAW);
            GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, a[2]);
            GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER, nI * 2, ib, GLES30.GL_STATIC_DRAW);
            GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, STRIDE, 0);
            GLES30.glVertexAttribPointer(1, 2, GLES30.GL_FLOAT, false, STRIDE, 12);
            GLES30.glVertexAttribPointer(2, 3, GLES30.GL_FLOAT, false, STRIDE, 20);
            GLES30.glVertexAttribPointer(3, 1, GLES30.GL_FLOAT, false, STRIDE, 32);
            for (int i = 0; i < 4; i++) GLES30.glEnableVertexAttribArray(i);
            GLES30.glBindVertexArray(0);

            // Texture trọng số gió: rộng = số mẫu thời gian, cao = số lá cỏ
            int[] t = new int[1];
            GLES30.glGenTextures(1, t, 0);
            windTex = t[0];
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, windTex);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_NEAREST);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_NEAREST);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE);
            GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 4);
            GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_R32F, nSamples, nBlades, 0,
                    GLES30.GL_RED, GLES30.GL_FLOAT, wb);
        } catch (java.io.IOException e) {
            throw new RuntimeException(e);
        }
    }

    private int loadGrassTexture() {
        try (InputStream in = context.getAssets().open("grass.png")) {
            Bitmap bmp = BitmapFactory.decodeStream(in);
            int[] t = new int[1];
            GLES30.glGenTextures(1, t, 0);
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, t[0]);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_NEAREST);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_NEAREST);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE);
            GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bmp, 0);
            bmp.recycle();
            return t[0];
        } catch (java.io.IOException e) {
            throw new RuntimeException(e);
        }
    }

    // ---------- shader ----------

    private static int compile(int type, String src) {
        int s = GLES30.glCreateShader(type);
        GLES30.glShaderSource(s, src);
        GLES30.glCompileShader(s);
        int[] ok = new int[1];
        GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, ok, 0);
        if (ok[0] == 0) {
            String log = GLES30.glGetShaderInfoLog(s);
            GLES30.glDeleteShader(s);
            throw new RuntimeException("Shader lỗi: " + log);
        }
        return s;
    }

    private static int link(int vs, int fs) {
        int p = GLES30.glCreateProgram();
        GLES30.glAttachShader(p, vs);
        GLES30.glAttachShader(p, fs);
        GLES30.glLinkProgram(p);
        int[] ok = new int[1];
        GLES30.glGetProgramiv(p, GLES30.GL_LINK_STATUS, ok, 0);
        if (ok[0] == 0) throw new RuntimeException("Link lỗi: " + GLES30.glGetProgramInfoLog(p));
        return p;
    }
}
