$input a_color0, a_texcoord1, a_position, a_texcoord0, i_data1, i_data2, i_data3
$output v_clipPosition, v_color0, v_ditheringAndMaskTinting, v_fog, v_lightmapUV, v_texcoord0, v_worldPos, v_worldPosition

#include <bgfx_shader.sh>
#include "grass_wind.sh"

uniform vec4 FogAndDistanceControl;
uniform vec4 FogColor;
uniform vec4 MeshContext;
uniform vec4 RenderChunkFogAlpha;
uniform vec4 SubPixelOffset;
uniform vec4 ViewPositionAndTime;

void main() {
    // ---- vi tri the gioi (tuong duong u_model[0] * a_position) ----
    vec3 worldPos;
#ifdef INSTANCING__ON
    // ma tran instance: hang i = i_dataN.xyzw
    worldPos = vec3(
        dot(i_data1.xyz, a_position) + i_data1.w,
        dot(i_data2.xyz, a_position) + i_data2.w,
        dot(i_data3.xyz, a_position) + i_data3.w);
#else
    worldPos = mul(u_model[0], vec4(a_position, 1.0)).xyz;
#endif

    // ---- GIO CHO CO ----
    // gy = do cao tren nen block; dinh o nen / dinh block day deu = 0 nen khong bi dich.
#ifdef RENDER_AS_BILLBOARDS__OFF
    float gy = fract(a_position.y + 0.002) - 0.002;
    worldPos += grassWindDisplace(gy, ViewPositionAndTime.w, worldPos.xz);
#endif

    // ---- billboard ----
    vec3 finalPos = worldPos;
#ifdef RENDER_AS_BILLBOARDS__ON
    vec3 c = worldPos + vec3(0.5, 0.5, 0.5);
    vec3 fwd = normalize(c - ViewPositionAndTime.xyz);
    vec3 right = normalize(cross(vec3(0.0, 1.0, 0.0), fwd));
    finalPos = c - ((cross(fwd, right) * (a_color0.z - 0.5)) + (right * (a_color0.x - 0.5)));
#endif

    // ---- fog ----
    vec4 fogCtl = FogAndDistanceControl;
    if (MeshContext.x > 0.5) {
        fogCtl = vec4(0.99, 1.0, 100000.0, 100000.0);
    }

    // ---- projection co jitter ----
    mat4 proj = u_proj;
#if BGFX_SHADER_LANGUAGE_GLSL
    proj[2][0] += SubPixelOffset.x;
    proj[2][1] -= SubPixelOffset.y;
#else
    proj[0][2] += SubPixelOffset.x;
    proj[1][2] -= SubPixelOffset.y;
#endif
    vec4 clipPos = mul(proj, mul(u_view, vec4(finalPos, 1.0)));

    // ---- giai ma UV (16 bit) ----
    uvec2 t0 = uvec2(round(a_texcoord0 * 65535.0));
    vec2 uv = vec2(float((t0.x & 32767u) << 1u), float((t0.y & 32767u) << 1u)) * 1.525902189314365386962890625e-05;
    uv.x += 3.0517578125e-05 * (2.0 * float((t0.x & 32768u) >> 15u) - 1.0);
    uv.y += 3.0517578125e-05 * (2.0 * float((t0.y & 32768u) >> 15u) - 1.0);

    uvec2 t1 = uvec2(round(a_texcoord1 * 65535.0));

#if defined(ALPHA_TEST_PASS) || defined(TRANSPARENT_PASS)
    v_clipPosition = clipPos;
    v_worldPosition = vec4(worldPos, 0.0);
#endif
#ifdef RENDER_AS_BILLBOARDS__OFF
    v_color0 = a_color0;
#else
    v_color0 = vec4(1.0, 1.0, 1.0, 1.0);
#endif
    v_ditheringAndMaskTinting = vec2(
        (t1.x & 256u) != 0u ? 1.0 : 0.0,
        (t1.y & 256u) != 0u ? 1.0 : 0.0);
    v_fog = vec4(FogColor.xyz,
        clamp((((length(ViewPositionAndTime.xyz - finalPos) / fogCtl.z) + RenderChunkFogAlpha.x) - fogCtl.x) / (fogCtl.y - fogCtl.x), 0.0, 1.0));
    v_lightmapUV = vec2(float((t1.y >> 4u) & 15u), float(t1.y & 15u)) * 0.066666670143604278564453125;
    v_texcoord0 = uv;
    v_worldPos = worldPos;
    gl_Position = clipPos;
}
