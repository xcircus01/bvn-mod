// ============================================================================
// grass_wind.sh  -  tái tạo animation "wind_sway" của infinite_grass_block
// bằng vertex shader (bgfx / RenderDragon, Bedrock).
//
// CHƯA được biên dịch hay chạy thử trong game. Công thức đã kiểm tra bằng
// Python với dữ liệu keyframe thật (sai số ngọn cỏ tối đa ~0.3 px của 16).
//
// Cách hoạt động:
//  - Mỗi cọng có 5 đoạn lồng nhau, mỗi đoạn xoay quanh trục X (góc uốn).
//  - Góc của đoạn j theo thời gian = trung bình + tổng 6 sóng sin/cos,
//    chu kỳ gốc 12 giây (hằng số fit từ 500 bone trong .bbmodel).
//  - Hướng của đoạn j = tổng góc các đoạn 0..j (giống bone cha -> con).
//  - Đỉnh ở độ cao y (đơn vị block) được dịch theo hướng gió.
//  - Mỗi cọng lệch thời gian / biên độ / góc nghiêng một chút (nhiễu mượt theo
//    vị trí), tái tạo việc các cọng trong animation gốc không đồng pha.
//
// Cách dùng trong vertex shader của material vẽ block (xem hướng dẫn kèm theo):
//     #include "grass_wind.sh"
//     float gy = fract(a_position.y + 0.002) - 0.002;   // độ cao trên nền block
//     worldPos.xyz += grassWindDisplace(gy, <giây>, worldPos.xz);
// ============================================================================

#ifndef GRASS_WIND_SH
#define GRASS_WIND_SH

// Chiều dài danh nghĩa của mỗi đoạn, đơn vị block (bbmodel: 2.24..3.2 / 16).
#define GRASS_SEG_LEN 0.17

// Hướng nghiêng trên mặt phẳng XZ. Nhóm "wind" trong bbmodel xoay -135 độ
// quanh Y, tương ứng khoảng (-0.7071, -0.7071). Nếu trong game cỏ nghiêng
// ngược hướng so với Blockbench, đổi dấu cả hai số.
#define GRASS_WIND_DIR vec2(-0.7071, -0.7071)

// Chu kỳ animation gốc (giây) và độ lệch pha theo không gian.
#define GRASS_PERIOD 12.0
#define GRASS_PHASE_PER_BLOCK vec2(0.13, 0.09)   // giây lệch pha mỗi block

// Nhân độ mạnh của gió (1.0 = đúng animation gốc, 0.0 = đứng yên).
#define GRASS_STRENGTH 1.0

// Độ khác nhau giữa các cọng (giống các cọng lệch nhau trong animation gốc).
// 1.0 = khớp mức đo được từ .bbmodel, 0.0 = mọi cọng chuyển động y hệt nhau.
#define GRASS_VARIATION 1.0
#define GRASS_VAR_SHIFT  0.9   // lệch thời gian tối đa (giây)
#define GRASS_VAR_AMP    0.16  // biến thiên biên độ (+-)
#define GRASS_VAR_OFFSET 2.0   // lệch góc nghiêng (độ)

// Góc của một đoạn (độ) tại pha w = 2*pi*t/12.
// cA/sA: sóng 1..3, cB/sB: sóng 4..6.  amp nhân phần dao động, off cộng vào góc.
float grassSegAngle(float mean, vec3 ca, vec3 cb, vec3 sa, vec3 sb,
                    vec3 cosA, vec3 cosB, vec3 sinA, vec3 sinB,
                    float amp, float off)
{
    return mean + off + amp * (dot(cosA, ca) + dot(cosB, cb) + dot(sinA, sa) + dot(sinB, sb));
}

// Nhiễu mượt theo vị trí (tổng 2 sóng sin), giá trị trong [-1, 1].
// Liên tục nên các đỉnh của cùng một cọng không bị xé, nhưng đổi đủ nhanh
// (chu kỳ ~0.25 block) để cọng cạnh nhau (cách 0.1 block) khác nhau.
float grassNoise(vec2 p, vec4 f, vec2 ph)
{
    return 0.5 * sin(dot(p, f.xy) + ph.x) + 0.5 * sin(dot(p, f.zw) + ph.y);
}

// Trả về độ dịch chuyển của đỉnh ở độ cao y (block), trong hệ tọa độ
// (dọc hướng gió, lên trên). Gồm: x = dịch theo gió, y = độ hạ xuống.
vec2 grassWindLocal(float y, float t, float amp, float off)
{
    t = mod(t, GRASS_PERIOD);   // giữ t nhỏ để sin/cos không mất độ chính xác
    float w = 6.2831853 * t / GRASS_PERIOD;

    vec3 cosA = cos(w * vec3(1.0, 2.0, 3.0));
    vec3 cosB = cos(w * vec3(4.0, 5.0, 6.0));
    vec3 sinA = sin(w * vec3(1.0, 2.0, 3.0));
    vec3 sinB = sin(w * vec3(4.0, 5.0, 6.0));

    float L = GRASS_SEG_LEN;
    float k = 0.017453293 * GRASS_STRENGTH; // độ -> radian, nhân độ mạnh

    float a0 = grassSegAngle(6.7106,
        vec3(1.3931, 0.5911, 1.4990), vec3(0.0813, -0.0944, -0.0591),
        vec3(0.4571, 0.6123, 1.2787), vec3(0.2244, -0.7256, -0.5654),
        cosA, cosB, sinA, sinB, amp, off);
    float a1 = grassSegAngle(12.3777,
        vec3(2.1003, 0.8865, 2.5134), vec3(0.0818, -0.1705, -0.1077),
        vec3(0.7318, 1.0107, 2.1568), vec3(0.3523, -1.2049, -0.9422),
        cosA, cosB, sinA, sinB, amp, off);
    float a2 = grassSegAngle(9.8656,
        vec3(0.7892, 0.3694, 1.4593), vec3(-0.0352, -0.1121, -0.0774),
        vec3(0.3511, 0.5563, 1.2571), vec3(0.1503, -0.6758, -0.5463),
        cosA, cosB, sinA, sinB, amp, off);
    float a3 = grassSegAngle(7.5929,
        vec3(0.0730, 0.1173, 0.6808), vec3(-0.0581, -0.0589, -0.0462),
        vec3(0.1054, 0.2440, 0.5837), vec3(0.0315, -0.3002, -0.2647),
        cosA, cosB, sinA, sinB, amp, off);
    float a4 = grassSegAngle(5.9210,
        vec3(-0.1961, 0.0159, 0.2392), vec3(-0.0465, -0.0277, -0.0231),
        vec3(-0.0084, 0.0782, 0.2063), vec3(-0.0135, -0.0971, -0.1050),
        cosA, cosB, sinA, sinB, amp, off);

    // Cộng dồn góc (bone cha -> con) và độ dài từng đoạn tính đến độ cao y.
    float c0 = a0 * k;
    float c1 = c0 + a1 * k;
    float c2 = c1 + a2 * k;
    float c3 = c2 + a3 * k;
    float c4 = c3 + a4 * k;

    float l0 = clamp(y,           0.0, L);
    float l1 = clamp(y - L,       0.0, L);
    float l2 = clamp(y - 2.0 * L, 0.0, L);
    float l3 = clamp(y - 3.0 * L, 0.0, L);
    float l4 = max(y - 4.0 * L, 0.0);        // đoạn cuối không giới hạn

    float dx = l0 * sin(c0) + l1 * sin(c1) + l2 * sin(c2) + l3 * sin(c3) + l4 * sin(c4);
    float dy = l0 * cos(c0) + l1 * cos(c1) + l2 * cos(c2) + l3 * cos(c3) + l4 * cos(c4);

    return vec2(dx, dy - y);
}

// Dùng hàm này: trả về vec3 độ dịch trong không gian thế giới (đơn vị block).
// y     : độ cao đỉnh trên nền block, 0..1
// t     : thời gian tính bằng giây
// posXZ : tọa độ thế giới (để lệch pha giữa các block)
vec3 grassWindDisplace(float y, float t, vec2 posXZ)
{
    float phase = dot(posXZ, GRASS_PHASE_PER_BLOCK);

    // Biến thiên riêng của từng cọng, suy ra từ vị trí (tọa độ thế giới, block).
    float v  = GRASS_VARIATION;
    float sh = v * GRASS_VAR_SHIFT  * grassNoise(posXZ, vec4( 23.0, 17.0, -19.0, -29.0), vec2(0.7, 2.1));
    float am = 1.0 + v * GRASS_VAR_AMP * grassNoise(posXZ, vec4( 31.0,-21.0,  17.0, -27.0), vec2(1.3, 4.0));
    float of = v * GRASS_VAR_OFFSET * grassNoise(posXZ, vec4(-27.0, 19.0,  21.0,  33.0), vec2(2.9, 5.2));

    vec2 d = grassWindLocal(max(y, 0.0), t + phase + sh, am, of);
    return vec3(GRASS_WIND_DIR.x * d.x, d.y, GRASS_WIND_DIR.y * d.x);
}

#endif // GRASS_WIND_SH
