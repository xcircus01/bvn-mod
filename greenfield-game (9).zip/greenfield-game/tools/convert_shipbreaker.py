"""Chuyển shipbreaker_full_spline.glb -> assets/shipbreaker.bin + assets/ship_0..4.png

Model là con rắn 71 xương (skinned mesh). Đường đi spline NẰM TRONG animation: xương gốc (spine_00)
được keyframe tịnh tiến/xoay dọc đường cong, các xương con bám theo. Runtime chỉ việc phát animation.

Định dạng shipbreaker.bin (little-endian, mọi mục căn 4 byte):
  header   : 'SHP1', nNodes, nJoints, nFrames, nMeshes, nTracks, nTargets, nWFrames,
             float frameDt, float wDt, wTexW, wRows, nVerts, nIdx                (14 từ)
  nodes    : nNodes   * [int parent, float T[3], float Q[4], int track]         (9 từ)
  tracks   : nTracks  * [int flags]   (1 = có tịnh tiến, 2 = có xoay)
  joints   : nJoints int (chỉ số node) + nJoints*16 float inverse-bind (cột trước, như glTF)
  trackdata: với mỗi track: T[nFrames*3] nếu flags&1, rồi Q[nFrames*4] nếu flags&2
  meshes   : nMeshes  * [int node, int firstIndex, int indexCount, int flags, int tex, int emi, float cutoff]
             flags: 1 = skinned, 2 = morph, 4 = doubleSided ; emi = -1 nếu không có
  verts    : nVerts * 20 float : pos3 nrm3 uv2 joints4 weights4 morphDelta3 morphIndex1
  indices  : nIdx uint16 (đệm cho đủ bội số 4 byte)
  morph    : (nTargets*wRows) hàng * wTexW half-float: trọng số morph, hàng = target*wRows + (frame>>10)
"""
import io
import json
import os
import struct
import sys

import numpy as np

src = sys.argv[1] if len(sys.argv) > 1 else "model/shipbreaker_full_spline.glb"
out = sys.argv[2] if len(sys.argv) > 2 else "app/src/main/assets"

# ---------------------------------------------------------------- đọc GLB
d = open(src, 'rb').read()
assert d[:4] == b'glTF'
off, j, bin_ = 12, None, None
while off < len(d):
    clen, ctype = struct.unpack('<II', d[off:off + 8])
    chunk = d[off + 8:off + 8 + clen]
    if ctype == 0x4E4F534A:
        j = json.loads(chunk)
    elif ctype == 0x004E4942:
        bin_ = chunk
    off += 8 + clen

CT = {5126: '<f4', 5123: '<u2', 5125: '<u4', 5121: 'u1', 5120: 'i1', 5122: '<i2'}
NC = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4, 'MAT4': 16}


def _raw(bv_i, byte_off, dt, n):
    bv = j['bufferViews'][bv_i]
    return np.frombuffer(bin_, dt, n, bv.get('byteOffset', 0) + byte_off)


def acc(i):
    """Đọc accessor (hỗ trợ sparse, bỏ qua byteStride vì file này không dùng)."""
    A = j['accessors'][i]
    nc, dt = NC[A['type']], CT[A['componentType']]
    if 'bufferView' in A:
        assert 'byteStride' not in j['bufferViews'][A['bufferView']], "byteStride chưa hỗ trợ"
        a = _raw(A['bufferView'], A.get('byteOffset', 0), dt, A['count'] * nc).reshape(A['count'], nc).copy()
    else:
        a = np.zeros((A['count'], nc), dt)
    if 'sparse' in A:
        sp = A['sparse']
        n = sp['count']
        idx = _raw(sp['indices']['bufferView'], sp['indices'].get('byteOffset', 0),
                   CT[sp['indices']['componentType']], n)
        val = _raw(sp['values']['bufferView'], sp['values'].get('byteOffset', 0), dt, n * nc).reshape(n, nc)
        a[idx] = val
    if A.get('normalized'):
        a = a.astype(np.float32) / float(np.iinfo(CT[A['componentType']]).max)
    return a


# ---------------------------------------------------------------- node
nodes = j['nodes']
N = len(nodes)
parent = [-1] * N
for i, n in enumerate(nodes):
    assert 'scale' not in n and 'matrix' not in n, "node có scale/matrix: chưa hỗ trợ"
    for c in n.get('children', []):
        parent[c] = i
for i in range(N):
    assert parent[i] < i, "node phải được sắp theo thứ tự cha trước con"

skin = j['skins'][0]
joints = skin['joints']
ibm = acc(skin['inverseBindMatrices']).astype('<f4')
nJ = len(joints)

# ---------------------------------------------------------------- animation
anim = j['animations'][0]
node_ch = {}
w_ch = None
for ch in anim['channels']:
    s = anim['samplers'][ch['sampler']]
    assert s.get('interpolation', 'LINEAR') == 'LINEAR', "chỉ hỗ trợ LINEAR"
    path = ch['target']['path']
    if path == 'weights':
        w_ch = (ch['target']['node'], acc(s['input']).ravel(), acc(s['output']).ravel())
    else:
        node_ch.setdefault(ch['target']['node'], {})[path] = (acc(s['input']).ravel(), acc(s['output']))

# thời gian của các track xương: phải đều nhau
t0 = None
for n, dct in node_ch.items():
    for path, (tin, _) in dct.items():
        if t0 is None:
            t0 = tin
        assert len(tin) == len(t0) and np.allclose(tin, t0), "các track xương không cùng mốc thời gian"
nFrames = len(t0)
frameDt = float(t0[1] - t0[0])
assert np.allclose(np.diff(t0), frameDt, atol=1e-4), "mốc thời gian không đều"

track_of = [-1] * N
track_flags, track_T, track_Q = [], [], []
for n in range(N):
    if n not in node_ch:
        continue
    dct = node_ch[n]
    f = 0
    T = Q = None
    if 'translation' in dct:
        f |= 1
        T = dct['translation'][1].astype('<f4')
    if 'rotation' in dct:
        f |= 2
        q = dct['rotation'][1].astype(np.float64)
        Q = (q / np.linalg.norm(q, axis=1, keepdims=True)).astype('<f4')
    track_of[n] = len(track_flags)
    track_flags.append(f)
    track_T.append(T)
    track_Q.append(Q)

# weights morph
mesh_morph_node = w_ch[0]
wt_in, wt_out = w_ch[1], w_ch[2]
nWFrames = len(wt_in)
wDt = float(wt_in[1] - wt_in[0])
assert np.allclose(np.diff(wt_in), wDt, atol=1e-4)
WTEXW = 1024

# ---------------------------------------------------------------- mesh
mesh_nodes = [n for n in range(N) if 'mesh' in nodes[n]]
verts, idxs, meshes = [], [], []
base = 0
nTargets = 0
for n in mesh_nodes:
    nd = nodes[n]
    prim = j['meshes'][nd['mesh']]['primitives'][0]
    at = prim['attributes']
    pos = acc(at['POSITION']).astype(np.float32)
    nrm = acc(at['NORMAL']).astype(np.float32)
    uv = acc(at['TEXCOORD_0']).astype(np.float32)
    nv = len(pos)
    skinned = 'skin' in nd
    if skinned:
        # mesh skinned nằm ở gốc với biến đổi đơn vị -> joint matrix = world(joint) * IBM
        assert parent[n] < 0 and 'translation' not in nd and 'rotation' not in nd
        jt = acc(at['JOINTS_0']).astype(np.float32)
        wt = acc(at['WEIGHTS_0']).astype(np.float32)
    else:
        jt = np.zeros((nv, 4), np.float32)
        wt = np.zeros((nv, 4), np.float32)
    md = np.zeros((nv, 3), np.float32)
    mi = np.full((nv, 1), -1.0, np.float32)
    flags = 1 if skinned else 0
    if 'targets' in prim:
        assert n == mesh_morph_node
        nTargets = len(prim['targets'])
        for k, tg in enumerate(prim['targets']):
            D = acc(tg['POSITION']).astype(np.float32)
            nz = np.where(np.abs(D).sum(1) > 0)[0]
            assert (mi[nz] < 0).all(), "một đỉnh thuộc nhiều morph target: chưa hỗ trợ"
            md[nz] = D[nz]
            mi[nz] = k
        flags |= 2
    mat = j['materials'][prim['material']]
    if mat.get('doubleSided'):
        flags |= 4
    pbr = mat['pbrMetallicRoughness']
    tex = j['textures'][pbr['baseColorTexture']['index']]['source']
    emi = j['textures'][mat['emissiveTexture']['index']]['source'] if 'emissiveTexture' in mat else -1
    cutoff = mat.get('alphaCutoff', 0.5) if mat.get('alphaMode') == 'MASK' else 0.0
    ind = acc(prim['indices']).ravel().astype(np.uint32) + base
    verts.append(np.hstack([pos, nrm, uv, jt, wt, md, mi]).astype('<f4'))
    meshes.append((n, sum(len(x) for x in idxs), len(ind), flags, tex, emi, cutoff))
    idxs.append(ind)
    base += nv
nV = base
assert nV < 65536, "quá 65535 đỉnh: cần index 32-bit"
V = np.vstack(verts)
I = np.concatenate(idxs).astype('<u2')
nI = len(I)

# bảng trọng số morph: [target][frame] -> texture rộng 1024, mỗi target chiếm wRows hàng
assert len(wt_out) == nWFrames * nTargets
Wm = wt_out.reshape(nWFrames, nTargets).T
wRows = (nWFrames + WTEXW - 1) // WTEXW
pad = np.zeros((nTargets, wRows * WTEXW), np.float32)
pad[:, :nWFrames] = Wm
pad[:, nWFrames:] = Wm[:, -1:]
Wtex = pad.reshape(nTargets * wRows, WTEXW).astype('<f2')

# ---------------------------------------------------------------- ghi file
os.makedirs(out, exist_ok=True)
with open(os.path.join(out, 'shipbreaker.bin'), 'wb') as f:
    f.write(b'SHP1')
    f.write(struct.pack('<7i', N, nJ, nFrames, len(meshes), len(track_flags), nTargets, nWFrames))
    f.write(struct.pack('<2f', frameDt, wDt))
    f.write(struct.pack('<4i', WTEXW, wRows, nV, nI))
    for n in range(N):
        nd = nodes[n]
        f.write(struct.pack('<i3f4fi', parent[n], *nd.get('translation', [0, 0, 0]),
                            *nd.get('rotation', [0, 0, 0, 1]), track_of[n]))
    for fl in track_flags:
        f.write(struct.pack('<i', fl))
    f.write(struct.pack('<%di' % nJ, *joints))
    f.write(ibm.tobytes())
    for fl, T, Q in zip(track_flags, track_T, track_Q):
        if fl & 1:
            f.write(T.tobytes())
        if fl & 2:
            f.write(Q.tobytes())
    for m in meshes:
        f.write(struct.pack('<6if', *m))
    f.write(V.tobytes())
    f.write(I.tobytes())
    if nI & 1:
        f.write(b'\0\0')
    f.write(Wtex.tobytes())

for i, img in enumerate(j['images']):
    bv = j['bufferViews'][img['bufferView']]
    s = bv.get('byteOffset', 0)
    open(os.path.join(out, 'ship_%d.png' % i), 'wb').write(bin_[s:s + bv['byteLength']])

size = os.path.getsize(os.path.join(out, 'shipbreaker.bin'))
print("nodes %d joints %d frames %d (dt %.3fs, %.1fs) meshes %d verts %d idx %d targets %d wframes %d"
      % (N, nJ, nFrames, frameDt, (nFrames - 1) * frameDt, len(meshes), nV, nI, nTargets, nWFrames))
print("shipbreaker.bin = %.2f MB" % (size / 1048576))
