package com.example.greenfield;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLES30;
import android.opengl.GLUtils;
import android.opengl.Matrix;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;

/**
 * Vẽ mob Shipbreaker (rắn 71 xương, skinned + morph) với đường đi spline nằm sẵn trong animation.
 *
 * Mỗi frame: MobModel nội suy keyframe -> ma trận xương trên CPU (71 xương, rất nhẹ), đẩy vào texture
 * 4x71 RGBA32F; vertex shader skinning + morph (348 target của "crest" đọc từ texture R16F).
 *
 * Cách dùng trong renderer chính:
 *   onSurfaceCreated: mob.initGL();
 *   onDrawFrame     : mob.draw(vp, eyeX, eyeY, eyeZ, elapsedSeconds, skyR, skyG, skyB);
 */
final class MobRenderer {
    private static final String TAG = "MobRenderer";

    // ======================= CẤU HÌNH (chỉnh ở đây) =======================
    /** Model dựng theo pixel kiểu Minecraft: 16 đơn vị model = 1 block. */
    static final float SCALE = 1f / 16f;
    /** Tốc độ phát animation (1 = đúng tốc độ gốc, clip dài 231 giây). */
    static final float PLAY_SPEED = 1f;
    /**
     * Bắt đầu clip từ giây thứ mấy. Với gốc đặt ở mặt đất (oy = 0), giây 0-10 và 196-231 con rắn còn/đã chìm
     * hẳn dưới đất (không vẽ), nên mặc định bắt đầu ở giây 8 để vào game là thấy nó trồi lên.
     */
    static final float START_TIME = 8f;
    /** Mob chìm hẳn dưới mặt đất (đã trừ lề) thì bỏ qua không vẽ. */
    private static final float HIDE_MARGIN = 3f;
    /** Sương mù riêng cho mob (block). Cỏ mờ ở 14..26 nên mob đặt xa hơn vẫn thấy rõ dần dần. */
    private static final float FOG_NEAR = 40f, FOG_FAR = 120f;
    // =====================================================================

    private static final int STRIDE = MobModel.VERT_FLOATS * 4;
    private static final int TEX_COUNT = 5;

    private static final String VS =
            "#version 300 es\n" +
            "precision highp float;\n" +
            "precision highp int;\n" +
            "precision highp sampler2D;\n" +
            "uniform mat4 uVP;\n" +
            "uniform mat4 uModel;\n" +
            "uniform vec3 uEye;\n" +
            "uniform vec2 uFogRange;\n" +
            "uniform int uSkinned;\n" +
            "uniform int uMorphOn;\n" +
            "uniform int uWF0;\n" +
            "uniform int uWF1;\n" +
            "uniform float uWFrac;\n" +
            "uniform int uWRows;\n" +
            "uniform sampler2D uBones;\n" +   // 4 x nJoints, mỗi texel = 1 cột của ma trận xương
            "uniform sampler2D uMorph;\n" +   // rộng 1024, mỗi target chiếm uWRows hàng
            "layout(location=0) in vec3 aPos;\n" +
            "layout(location=1) in vec3 aNrm;\n" +
            "layout(location=2) in vec2 aUV;\n" +
            "layout(location=3) in vec4 aJoints;\n" +
            "layout(location=4) in vec4 aWeights;\n" +
            "layout(location=5) in vec4 aMorph;\n" +   // xyz = độ lệch, w = chỉ số target (-1 = không morph)
            "out vec2 vUV;\n" +
            "out vec3 vN;\n" +
            "out float vFog;\n" +
            "mat4 bone(int j){\n" +
            "  return mat4(texelFetch(uBones, ivec2(0, j), 0), texelFetch(uBones, ivec2(1, j), 0),\n" +
            "              texelFetch(uBones, ivec2(2, j), 0), texelFetch(uBones, ivec2(3, j), 0));\n" +
            "}\n" +
            "float morphW(int k, int f){\n" +
            "  return texelFetch(uMorph, ivec2(f & 1023, k * uWRows + (f >> 10)), 0).r;\n" +
            "}\n" +
            "void main(){\n" +
            "  vec3 p = aPos;\n" +
            "  vec3 n = aNrm;\n" +
            "  if (uMorphOn == 1 && aMorph.w > -0.5) {\n" +
            "    int k = int(aMorph.w + 0.5);\n" +
            "    p += aMorph.xyz * mix(morphW(k, uWF0), morphW(k, uWF1), uWFrac);\n" +
            "  }\n" +
            "  if (uSkinned == 1) {\n" +
            "    mat4 s = bone(int(aJoints.x + 0.5)) * aWeights.x\n" +
            "           + bone(int(aJoints.y + 0.5)) * aWeights.y\n" +
            "           + bone(int(aJoints.z + 0.5)) * aWeights.z\n" +
            "           + bone(int(aJoints.w + 0.5)) * aWeights.w;\n" +
            "    p = (s * vec4(p, 1.0)).xyz;\n" +
            "    n = mat3(s) * n;\n" +
            "  }\n" +
            "  vec4 wp = uModel * vec4(p, 1.0);\n" +
            "  vN = mat3(uModel) * n;\n" +
            "  vUV = aUV;\n" +
            "  vFog = clamp((distance(wp.xyz, uEye) - uFogRange.x) / (uFogRange.y - uFogRange.x), 0.0, 1.0);\n" +
            "  gl_Position = uVP * wp;\n" +
            "}\n";

    private static final String FS =
            "#version 300 es\n" +
            "precision mediump float;\n" +
            "uniform sampler2D uTex;\n" +
            "uniform sampler2D uEmi;\n" +
            "uniform int uHasEmi;\n" +
            "uniform float uCut;\n" +
            "uniform vec3 uFogColor;\n" +
            "in vec2 vUV;\n" +
            "in vec3 vN;\n" +
            "in float vFog;\n" +
            "out vec4 outColor;\n" +
            "void main(){\n" +
            "  vec4 c = texture(uTex, vUV);\n" +
            "  if (c.a < uCut) discard;\n" +                      // alphaMode MASK của glTF
            "  vec3 n = normalize(vN);\n" +
            "  if (!gl_FrontFacing) n = -n;\n" +                  // thân 2 mặt
            "  float l = 0.5 + 0.5 * max(dot(n, normalize(vec3(0.35, 0.85, 0.4))), 0.0);\n" +
            "  vec3 col = c.rgb * l;\n" +
            "  if (uHasEmi == 1) col += texture(uEmi, vUV).rgb;\n" +   // mắt/hoa văn phát sáng
            "  outColor = vec4(mix(col, uFogColor, vFog), 1.0);\n" +
            "}\n";

    private final Context context;
    private MobModel model;              // đọc 1 lần, giữ lại khi GL context bị tạo lại
    private boolean ready = false;

    private int program, vao, boneTex, morphTex;
    private final int[] tex = new int[TEX_COUNT];
    private int uVP, uModel, uEye, uFogRange, uSkinned, uMorphOn, uWF0, uWF1, uWFrac, uWRows;
    private int uBones, uMorph, uTex, uEmi, uHasEmi, uCut, uFogColor;
    private FloatBuffer paletteBuf;

    private final float[] modelBase = new float[16];
    private final float[] tmp = new float[16];

    // vị trí đặt mob trong thế giới: gốc toạ độ của đường spline, và góc xoay quanh trục Y
    private float ox = 0f, oy = 0f, oz = -22f, yawDeg = 0f;

    MobRenderer(Context context) {
        this.context = context.getApplicationContext();
    }

    /** Đặt gốc của đường đi trong thế giới (block) và xoay cả đường đi quanh trục Y (độ). */
    void setPlacement(float x, float y, float z, float yawDegrees) {
        ox = x;
        oy = y;
        oz = z;
        yawDeg = yawDegrees;
    }

    /** Tạo tài nguyên GL. Gọi trong onSurfaceCreated (mỗi lần GL context được tạo lại). */
    void initGL() {
        ready = false;
        try {
            if (model == null) {
                try (InputStream in = context.getAssets().open("shipbreaker.bin")) {
                    model = MobModel.load(in);
                }
            }
            program = link(compile(GLES30.GL_VERTEX_SHADER, VS), compile(GLES30.GL_FRAGMENT_SHADER, FS));
            uVP = GLES30.glGetUniformLocation(program, "uVP");
            uModel = GLES30.glGetUniformLocation(program, "uModel");
            uEye = GLES30.glGetUniformLocation(program, "uEye");
            uFogRange = GLES30.glGetUniformLocation(program, "uFogRange");
            uSkinned = GLES30.glGetUniformLocation(program, "uSkinned");
            uMorphOn = GLES30.glGetUniformLocation(program, "uMorphOn");
            uWF0 = GLES30.glGetUniformLocation(program, "uWF0");
            uWF1 = GLES30.glGetUniformLocation(program, "uWF1");
            uWFrac = GLES30.glGetUniformLocation(program, "uWFrac");
            uWRows = GLES30.glGetUniformLocation(program, "uWRows");
            uBones = GLES30.glGetUniformLocation(program, "uBones");
            uMorph = GLES30.glGetUniformLocation(program, "uMorph");
            uTex = GLES30.glGetUniformLocation(program, "uTex");
            uEmi = GLES30.glGetUniformLocation(program, "uEmi");
            uHasEmi = GLES30.glGetUniformLocation(program, "uHasEmi");
            uCut = GLES30.glGetUniformLocation(program, "uCut");
            uFogColor = GLES30.glGetUniformLocation(program, "uFogColor");

            uploadGeometry();
            uploadAnimationTextures();
            for (int i = 0; i < TEX_COUNT; i++) tex[i] = loadTexture("ship_" + i + ".png");
            paletteBuf = ByteBuffer.allocateDirect(model.palette.length * 4)
                    .order(ByteOrder.nativeOrder()).asFloatBuffer();
            ready = true;
        } catch (Exception e) {
            Log.e(TAG, "Không khởi tạo được mob (game vẫn chạy, chỉ không có mob)", e);
        }
    }

    /**
     * Vẽ mob. Gọi sau khi vẽ mặt đất/cỏ (đã có depth) để phần thân chìm dưới đất bị che đúng.
     *
     * @param vp      ma trận projection * view
     * @param timeSec thời gian chạy của game (giây)
     */
    void draw(float[] vp, float eyeX, float eyeY, float eyeZ, float timeSec, float skyR, float skyG, float skyB) {
        if (!ready) return;
        MobModel m = model;

        float t = (START_TIME + timeSec * PLAY_SPEED) % m.duration;
        m.update(t);

        Matrix.setIdentityM(modelBase, 0);
        Matrix.translateM(modelBase, 0, ox, oy, oz);
        Matrix.rotateM(modelBase, 0, yawDeg, 0f, 1f, 0f);
        Matrix.scaleM(modelBase, 0, SCALE, SCALE, SCALE);

        // thân chìm hẳn dưới đất (đầu đường đi và cuối đường đi) -> khỏi vẽ
        if (m.maxJointY * SCALE + oy + HIDE_MARGIN < 0f) return;

        GLES30.glUseProgram(program);
        GLES30.glUniformMatrix4fv(uVP, 1, false, vp, 0);
        GLES30.glUniform3f(uEye, eyeX, eyeY, eyeZ);
        GLES30.glUniform3f(uFogColor, skyR, skyG, skyB);
        GLES30.glUniform2f(uFogRange, FOG_NEAR, FOG_FAR);
        GLES30.glUniform1i(uWF0, m.wFrame0);
        GLES30.glUniform1i(uWF1, m.wFrame1);
        GLES30.glUniform1f(uWFrac, m.wFrac);
        GLES30.glUniform1i(uWRows, m.wRows);
        GLES30.glUniform1i(uTex, 0);
        GLES30.glUniform1i(uEmi, 1);
        GLES30.glUniform1i(uBones, 2);
        GLES30.glUniform1i(uMorph, 3);

        // ma trận xương của frame này
        GLES30.glActiveTexture(GLES30.GL_TEXTURE2);
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, boneTex);
        paletteBuf.position(0);
        paletteBuf.put(m.palette);
        paletteBuf.position(0);
        GLES30.glTexSubImage2D(GLES30.GL_TEXTURE_2D, 0, 0, 0, 4, m.nJoints,
                GLES30.GL_RGBA, GLES30.GL_FLOAT, paletteBuf);
        GLES30.glActiveTexture(GLES30.GL_TEXTURE3);
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, morphTex);

        GLES30.glBindVertexArray(vao);
        for (int i = 0; i < m.nMeshes; i++) {
            int fl = m.meshFlags[i];
            boolean skinned = (fl & MobModel.FLAG_SKINNED) != 0;
            if (skinned) {
                GLES30.glUniformMatrix4fv(uModel, 1, false, modelBase, 0);
            } else {
                // mesh cứng (các hàm/đầu) gắn vào node của xương -> nhân thêm ma trận node
                Matrix.multiplyMM(tmp, 0, modelBase, 0, m.world, m.meshNode[i] * 16);
                GLES30.glUniformMatrix4fv(uModel, 1, false, tmp, 0);
            }
            GLES30.glUniform1i(uSkinned, skinned ? 1 : 0);
            GLES30.glUniform1i(uMorphOn, (fl & MobModel.FLAG_MORPH) != 0 ? 1 : 0);
            GLES30.glUniform1f(uCut, m.meshCutoff[i]);
            int emi = m.meshEmi[i];
            GLES30.glUniform1i(uHasEmi, emi >= 0 ? 1 : 0);
            GLES30.glActiveTexture(GLES30.GL_TEXTURE0);
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, tex[m.meshTex[i]]);
            GLES30.glActiveTexture(GLES30.GL_TEXTURE1);
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, tex[emi >= 0 ? emi : m.meshTex[i]]);
            GLES30.glDrawElements(GLES30.GL_TRIANGLES, m.meshIndexCount[i], GLES30.GL_UNSIGNED_SHORT,
                    m.meshFirstIndex[i] * 2);
        }
        GLES30.glBindVertexArray(0);
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0);
    }

    /**
     * Vị trí thế giới (block) của khớp k (0 = gần đầu nhất ... 70 = đuôi) ở frame vừa vẽ gần nhất.
     * Dùng cho va chạm, AI, bắn trúng... Trả về false nếu mob chưa sẵn sàng.
     */
    boolean getJointWorldPosition(int k, float[] out3) {
        if (!ready) return false;
        float[] in = new float[4];
        float[] res = new float[4];
        model.jointPosition(k, in);
        in[3] = 1f;
        Matrix.multiplyMV(res, 0, modelBase, 0, in, 0);
        out3[0] = res[0];
        out3[1] = res[1];
        out3[2] = res[2];
        return true;
    }

    // ---------------------------------------------------------------- tải dữ liệu lên GPU

    private void uploadGeometry() {
        MobModel m = model;
        int[] a = new int[3];
        GLES30.glGenVertexArrays(1, a, 0);
        vao = a[0];
        GLES30.glBindVertexArray(vao);
        GLES30.glGenBuffers(2, a, 1);

        FloatBuffer fb = ByteBuffer.allocateDirect(m.vertices.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        fb.put(m.vertices);
        fb.position(0);
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, a[1]);
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, m.vertices.length * 4, fb, GLES30.GL_STATIC_DRAW);

        ShortBuffer sb = ByteBuffer.allocateDirect(m.indices.length * 2).order(ByteOrder.nativeOrder()).asShortBuffer();
        sb.put(m.indices);
        sb.position(0);
        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, a[2]);
        GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER, m.indices.length * 2, sb, GLES30.GL_STATIC_DRAW);

        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, STRIDE, 0);    // pos
        GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, STRIDE, 12);   // normal
        GLES30.glVertexAttribPointer(2, 2, GLES30.GL_FLOAT, false, STRIDE, 24);   // uv
        GLES30.glVertexAttribPointer(3, 4, GLES30.GL_FLOAT, false, STRIDE, 32);   // joints
        GLES30.glVertexAttribPointer(4, 4, GLES30.GL_FLOAT, false, STRIDE, 48);   // weights
        GLES30.glVertexAttribPointer(5, 4, GLES30.GL_FLOAT, false, STRIDE, 64);   // morph delta + index
        for (int i = 0; i < 6; i++) GLES30.glEnableVertexAttribArray(i);
        GLES30.glBindVertexArray(0);
    }

    private void uploadAnimationTextures() {
        MobModel m = model;
        int[] t = new int[2];
        GLES30.glGenTextures(2, t, 0);

        // ma trận xương: 4 texel (4 cột) x nJoints hàng, float32 nên chỉ dùng NEAREST
        boneTex = t[0];
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, boneTex);
        nearestClamp();
        GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA32F, 4, m.nJoints, 0,
                GLES30.GL_RGBA, GLES30.GL_FLOAT, (java.nio.Buffer) null);

        // trọng số morph của "crest": half-float, rộng wTexW, cao nTargets * wRows
        morphTex = t[1];
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, morphTex);
        nearestClamp();
        ShortBuffer mb = ByteBuffer.allocateDirect(m.morphHalf.length * 2).order(ByteOrder.nativeOrder()).asShortBuffer();
        mb.put(m.morphHalf);
        mb.position(0);
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 4);
        GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_R16F, m.wTexW, m.nTargets * m.wRows, 0,
                GLES30.GL_RED, GLES30.GL_HALF_FLOAT, mb);
    }

    private static void nearestClamp() {
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_NEAREST);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_NEAREST);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE);
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE);
    }

    private int loadTexture(String asset) throws IOException {
        try (InputStream in = context.getAssets().open(asset)) {
            Bitmap bmp = BitmapFactory.decodeStream(in);
            if (bmp == null) throw new IOException("Không giải mã được " + asset);
            int[] t = new int[1];
            GLES30.glGenTextures(1, t, 0);
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, t[0]);
            // pixel-art (giống glTF gốc: NEAREST + REPEAT)
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_NEAREST);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_NEAREST);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_REPEAT);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_REPEAT);
            GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bmp, 0);
            bmp.recycle();
            return t[0];
        }
    }

    // ---------------------------------------------------------------- shader

    private static int compile(int type, String src) {
        int s = GLES30.glCreateShader(type);
        GLES30.glShaderSource(s, src);
        GLES30.glCompileShader(s);
        int[] ok = new int[1];
        GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, ok, 0);
        if (ok[0] == 0) {
            String log = GLES30.glGetShaderInfoLog(s);
            GLES30.glDeleteShader(s);
            throw new RuntimeException("Shader mob lỗi: " + log);
        }
        return s;
    }

    private static int link(int vs, int fs) {
        int p = GLES30.glCreateProgram();
        GLES30.glAttachShader(p, vs);
        GLES30.glAttachShader(p, fs);
        GLES30.glLinkProgram(p);
        int[] ok = new int[1];
        GLES30.glGetProgramiv(p, GLES30.GL_LINK_STATUS, ok, 0);
        if (ok[0] == 0) throw new RuntimeException("Link mob lỗi: " + GLES30.glGetProgramInfoLog(p));
        return p;
    }
}
