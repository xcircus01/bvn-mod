package com.example.greenfield;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * Dữ liệu + animation của mob (đọc từ assets/shipbreaker.bin, tạo bởi tools/convert_shipbreaker.py).
 *
 * Đường đi spline nằm TRONG animation: xương gốc được keyframe dọc đường cong, các xương con bám theo.
 * Ở đây chỉ việc nội suy keyframe -> ma trận xương (palette) cho thời điểm t. Class này không dùng
 * Android/OpenGL nên chạy được trên JVM thường (để test).
 *
 * Ma trận lưu cột trước (column-major) giống OpenGL/glTF: m[cột * 4 + hàng].
 */
final class MobModel {
    /** Số float mỗi đỉnh: pos3 nrm3 uv2 joints4 weights4 morphDelta3 morphIndex1. */
    static final int VERT_FLOATS = 20;

    static final int FLAG_SKINNED = 1, FLAG_MORPH = 2, FLAG_DOUBLE_SIDED = 4;

    // ---- kích thước ----
    int nNodes, nJoints, nFrames, nMeshes, nTracks, nTargets, nWFrames, wTexW, wRows, nVerts, nIdx;
    float frameDt, wDt;

    // ---- cây node + xương ----
    int[] parent, track, trackFlags, jointNode;
    float[] restT, restQ, ibm;
    float[][] trackT, trackQ;

    // ---- mesh ----
    int[] meshNode, meshFirstIndex, meshIndexCount, meshFlags, meshTex, meshEmi;
    float[] meshCutoff;
    float[] vertices;        // nVerts * VERT_FLOATS
    short[] indices;         // nIdx
    short[] morphHalf;       // (nTargets * wRows) * wTexW half-float

    // ---- kết quả của update() ----
    final float[] world;     // nNodes * 16: ma trận thế giới (không gian model) của từng node
    final float[] palette;   // nJoints * 16: ma trận skinning = world(joint) * inverseBind
    float maxJointY;         // độ cao lớn nhất của các khớp (đơn vị model) -> để biết mob có đang ở trên mặt đất không
    int wFrame0, wFrame1;    // hai khung trọng số morph cần nội suy
    float wFrac;
    float duration;          // độ dài clip (giây)

    private final float[] local = new float[16];

    static MobModel load(InputStream in) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream(1 << 22);
        byte[] buf = new byte[1 << 16];
        int n;
        while ((n = in.read(buf)) != -1) bos.write(buf, 0, n);
        return new MobModel(ByteBuffer.wrap(bos.toByteArray()).order(ByteOrder.LITTLE_ENDIAN));
    }

    private MobModel(ByteBuffer b) throws IOException {
        if (b.getInt() != 0x31504853) throw new IOException("shipbreaker.bin sai định dạng"); // 'SHP1'
        nNodes = b.getInt();
        nJoints = b.getInt();
        nFrames = b.getInt();
        nMeshes = b.getInt();
        nTracks = b.getInt();
        nTargets = b.getInt();
        nWFrames = b.getInt();
        frameDt = b.getFloat();
        wDt = b.getFloat();
        wTexW = b.getInt();
        wRows = b.getInt();
        nVerts = b.getInt();
        nIdx = b.getInt();

        parent = new int[nNodes];
        track = new int[nNodes];
        restT = new float[nNodes * 3];
        restQ = new float[nNodes * 4];
        for (int i = 0; i < nNodes; i++) {
            parent[i] = b.getInt();
            for (int k = 0; k < 3; k++) restT[i * 3 + k] = b.getFloat();
            for (int k = 0; k < 4; k++) restQ[i * 4 + k] = b.getFloat();
            track[i] = b.getInt();
        }
        trackFlags = new int[nTracks];
        for (int i = 0; i < nTracks; i++) trackFlags[i] = b.getInt();

        jointNode = new int[nJoints];
        for (int i = 0; i < nJoints; i++) jointNode[i] = b.getInt();
        ibm = floats(b, nJoints * 16);

        trackT = new float[nTracks][];
        trackQ = new float[nTracks][];
        for (int i = 0; i < nTracks; i++) {
            if ((trackFlags[i] & 1) != 0) trackT[i] = floats(b, nFrames * 3);
            if ((trackFlags[i] & 2) != 0) trackQ[i] = floats(b, nFrames * 4);
        }

        meshNode = new int[nMeshes];
        meshFirstIndex = new int[nMeshes];
        meshIndexCount = new int[nMeshes];
        meshFlags = new int[nMeshes];
        meshTex = new int[nMeshes];
        meshEmi = new int[nMeshes];
        meshCutoff = new float[nMeshes];
        for (int i = 0; i < nMeshes; i++) {
            meshNode[i] = b.getInt();
            meshFirstIndex[i] = b.getInt();
            meshIndexCount[i] = b.getInt();
            meshFlags[i] = b.getInt();
            meshTex[i] = b.getInt();
            meshEmi[i] = b.getInt();
            meshCutoff[i] = b.getFloat();
        }

        vertices = floats(b, nVerts * VERT_FLOATS);
        indices = shorts(b, nIdx);
        if ((nIdx & 1) != 0) b.position(b.position() + 2);   // đệm cho đủ bội số 4 byte
        morphHalf = shorts(b, nTargets * wRows * wTexW);

        world = new float[nNodes * 16];
        palette = new float[nJoints * 16];
        duration = (nFrames - 1) * frameDt;
        update(0f);
    }

    private static float[] floats(ByteBuffer b, int n) {
        float[] a = new float[n];
        b.asFloatBuffer().get(a);
        b.position(b.position() + n * 4);
        return a;
    }

    private static short[] shorts(ByteBuffer b, int n) {
        short[] a = new short[n];
        b.asShortBuffer().get(a);
        b.position(b.position() + n * 2);
        return a;
    }

    /** Tính pose tại thời điểm t giây (0 .. duration). t ngoài khoảng sẽ bị kẹp. */
    void update(float t) {
        float ft = t / frameDt;
        int f0 = (int) ft;
        if (f0 < 0) f0 = 0;
        int f1;
        float fr;
        if (f0 >= nFrames - 1) {
            f0 = f1 = nFrames - 1;
            fr = 0f;
        } else {
            f1 = f0 + 1;
            fr = ft - f0;
        }

        for (int n = 0; n < nNodes; n++) {
            float tx = restT[n * 3], ty = restT[n * 3 + 1], tz = restT[n * 3 + 2];
            float qx = restQ[n * 4], qy = restQ[n * 4 + 1], qz = restQ[n * 4 + 2], qw = restQ[n * 4 + 3];
            int tr = track[n];
            if (tr >= 0) {
                float[] T = trackT[tr];
                if (T != null) {
                    int a = f0 * 3, c = f1 * 3;
                    tx = T[a] + (T[c] - T[a]) * fr;
                    ty = T[a + 1] + (T[c + 1] - T[a + 1]) * fr;
                    tz = T[a + 2] + (T[c + 2] - T[a + 2]) * fr;
                }
                float[] Q = trackQ[tr];
                if (Q != null) {
                    int a = f0 * 4, c = f1 * 4;
                    float s = (Q[a] * Q[c] + Q[a + 1] * Q[c + 1] + Q[a + 2] * Q[c + 2] + Q[a + 3] * Q[c + 3]) < 0f ? -1f : 1f;
                    qx = Q[a] + (s * Q[c] - Q[a]) * fr;
                    qy = Q[a + 1] + (s * Q[c + 1] - Q[a + 1]) * fr;
                    qz = Q[a + 2] + (s * Q[c + 2] - Q[a + 2]) * fr;
                    qw = Q[a + 3] + (s * Q[c + 3] - Q[a + 3]) * fr;
                    float inv = 1f / (float) Math.sqrt(qx * qx + qy * qy + qz * qz + qw * qw);
                    qx *= inv;
                    qy *= inv;
                    qz *= inv;
                    qw *= inv;
                }
            }
            compose(local, tx, ty, tz, qx, qy, qz, qw);
            int p = parent[n];
            if (p < 0) System.arraycopy(local, 0, world, n * 16, 16);
            else mul(world, n * 16, world, p * 16, local, 0);    // node được sắp cha trước con
        }

        float maxY = -Float.MAX_VALUE;
        for (int k = 0; k < nJoints; k++) {
            int jn = jointNode[k] * 16;
            mul(palette, k * 16, world, jn, ibm, k * 16);
            if (world[jn + 13] > maxY) maxY = world[jn + 13];
        }
        maxJointY = maxY;

        // trọng số morph (animation riêng, 10 khung/giây)
        float wf = t / wDt;
        int w0 = (int) wf;
        if (w0 < 0) w0 = 0;
        if (w0 >= nWFrames - 1) {
            wFrame0 = wFrame1 = nWFrames - 1;
            wFrac = 0f;
        } else {
            wFrame0 = w0;
            wFrame1 = w0 + 1;
            wFrac = wf - w0;
        }
    }

    /** Vị trí khớp k (đơn vị model) -> out[0..2]. Dùng cho va chạm/AI, ví dụ k = 0 là đuôi-gần-đầu. */
    void jointPosition(int k, float[] out) {
        int o = jointNode[k] * 16;
        out[0] = world[o + 12];
        out[1] = world[o + 13];
        out[2] = world[o + 14];
    }

    // ---------------------------------------------------------------- toán ma trận (cột trước)

    private static void compose(float[] m, float tx, float ty, float tz, float x, float y, float z, float w) {
        float xx = x * x, yy = y * y, zz = z * z, xy = x * y, xz = x * z, yz = y * z, wx = w * x, wy = w * y, wz = w * z;
        m[0] = 1f - 2f * (yy + zz);
        m[1] = 2f * (xy + wz);
        m[2] = 2f * (xz - wy);
        m[3] = 0f;
        m[4] = 2f * (xy - wz);
        m[5] = 1f - 2f * (xx + zz);
        m[6] = 2f * (yz + wx);
        m[7] = 0f;
        m[8] = 2f * (xz + wy);
        m[9] = 2f * (yz - wx);
        m[10] = 1f - 2f * (xx + yy);
        m[11] = 0f;
        m[12] = tx;
        m[13] = ty;
        m[14] = tz;
        m[15] = 1f;
    }

    /** o = a * b (không được chồng lấn vùng nhớ với a hoặc b). */
    private static void mul(float[] o, int oo, float[] a, int ao, float[] b, int bo) {
        for (int c = 0; c < 4; c++) {
            float b0 = b[bo + c * 4], b1 = b[bo + c * 4 + 1], b2 = b[bo + c * 4 + 2], b3 = b[bo + c * 4 + 3];
            for (int r = 0; r < 4; r++) {
                o[oo + c * 4 + r] = a[ao + r] * b0 + a[ao + 4 + r] * b1 + a[ao + 8 + r] * b2 + a[ao + 12 + r] * b3;
            }
        }
    }
}
