package com.example.greenfield;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLES30;
import android.opengl.GLSurfaceView;
import android.opengl.GLUtils;
import android.opengl.Matrix;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/**
 * Vẽ nền phẳng xanh lá đậm + cỏ từ model infinite_grass_block (1x1 đơn vị, giống 1 block Minecraft).
 * Block cỏ được lát (tile) vô hạn quanh camera bằng instancing, tất cả cùng một hướng; camera tự do (di chuyển + xoay),
 * cỏ có sẵn đều khắp map và đung đưa theo animation wind_sway của GLB.
 */
public class GrassRenderer implements GLSurfaceView.Renderer {
    private static final int R = 26;               // bán kính vùng cỏ quanh camera (ô) = tầm nhìn
    private static final int SIDE = 2 * R + 1;
    private static final float NEAR_R = 12f;       // trong bán kính này luôn vẽ cỏ (khi nhìn xuống/quay nhanh)
    private static final float EYE_STAND = 1.62f;  // độ cao mắt nhân vật Minecraft (cao 1.8 block)
    private static final float EYE_SNEAK = 1.27f;  // độ cao mắt khi ngồi
    private static final float SNEAK_SPEED = 0.3f; // hệ số tốc độ khi ngồi
    private static final float JUMP_V = 8.8f;      // block/giây -> nhảy cao ~1.2 block
    private static final float GRAVITY = 32f;      // block/giây^2
    private static final float FOV = 60f;
    private static final float WALK_SPEED = 4.3f;   // block/giây (tốc độ đi bộ Minecraft)
    private static final int STRIDE = 9 * 4;       // pos3 uv2 morph3 blade1

    // Màu trời (cũng là màu sương mù: cỏ và đất ở xa mờ dần về màu trời, không để lộ dải đất xanh)
    private static final float SKY_R = 1f, SKY_G = 1f, SKY_B = 1f;

    // Nền xanh lá đậm
    private static final float GR = 11f / 255f, GG = 61f / 255f, GB = 11f / 255f;

    private static final String VS =
            "#version 300 es\n" +
            "uniform mat4 uVP;\n" +
            "uniform vec3 uEye;\n" +
            "uniform float uTime;\n" +      // 0..12 giây (lặp)
            "uniform highp sampler2D uWind;\n" +
            "layout(location=0) in vec3 aPos;\n" +
            "layout(location=1) in vec2 aUV;\n" +
            "layout(location=2) in vec3 aMorph;\n" +
            "layout(location=3) in float aBlade;\n" +
            "layout(location=4) in vec2 aTile;\n" +
            "out vec2 vUV;\n" +
            "out float vFog;\n" +
            // hash rẻ (không dùng sin) + value noise mượt theo toạ độ thế giới
            "float hash(vec2 p){\n" +
            "  vec3 q = fract(vec3(p.xyx) * 0.1031);\n" +
            "  q += dot(q, q.yzx + 33.33);\n" +
            "  return fract((q.x + q.y) * q.z);\n" +
            "}\n" +
            "float vnoise(vec2 p){\n" +
            "  vec2 i = floor(p), f = fract(p);\n" +
            "  f = f * f * (3.0 - 2.0 * f);\n" +
            "  return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x),\n" +
            "             mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x), f.y);\n" +
            "}\n" +
            "void main(){\n" +
            "  vec2 tile = aTile;\n" +
            // sóng gió lan qua các ô
            "  float t = mod(uTime + tile.x * 0.23 + tile.y * 0.37, 12.0);\n" +
            "  float f = t / 12.0 * 360.0;\n" +
            "  int i0 = int(floor(f)) % 360;\n" +
            "  int i1 = (i0 + 1) % 360;\n" +
            "  int b = int(aBlade + 0.5);\n" +
            "  float w = mix(texelFetch(uWind, ivec2(i0, b), 0).r,\n" +
            "                texelFetch(uWind, ivec2(i1, b), 0).r, fract(f));\n" +
            // Độ cao thông minh: mảng cỏ cao/thấp liền mạch theo vị trí thật (không lộ ranh giới ô),
            // cộng chút khác biệt riêng từng lá; cỏ cao thì ngả theo gió nhiều hơn.
            "  vec2 wp = tile + aPos.xz;\n" +
            "  float n = 0.65 * vnoise(wp * 0.09) + 0.35 * vnoise(wp * 0.4 + 31.7);\n" +
            "  n = smoothstep(0.25, 0.75, n);\n" +
            "  float hs = mix(0.6, 1.15, n) * (0.88 + 0.24 * hash(vec2(aBlade, tile.x * 7.13 + tile.y * 13.7)));\n" +
            "  vec3 p = vec3(aPos.x + aMorph.x * w * hs,\n" +
            "                (aPos.y + aMorph.y * w) * hs,\n" +
            "                aPos.z + aMorph.z * w * hs);\n" +
            "  vec3 world = vec3(tile.x + p.x, p.y, tile.y + p.z);\n" +
            "  vUV = aUV;\n" +
            "  vFog = clamp((distance(world, uEye) - 14.0) / 12.0, 0.0, 1.0);\n" +
            "  gl_Position = uVP * vec4(world, 1.0);\n" +
            "}\n";

    // Mặt đất thật: một tấm phẳng khổng lồ ở y = 0, luôn nằm quanh camera nên kéo dài tới chân trời
    private static final String GROUND_VS =
            "#version 300 es\n" +
            "uniform mat4 uVP;\n" +
            "uniform vec2 uCenter;\n" +
            "uniform float uSize;\n" +
            "uniform float uY;\n" +
            "out vec2 vXZ;\n" +
            "void main(){\n" +
            "  vec2 c = vec2(float(gl_VertexID & 1) * 2.0 - 1.0, float((gl_VertexID >> 1) & 1) * 2.0 - 1.0);\n" +
            "  vec2 p = uCenter + c * uSize;\n" +
            "  vXZ = p;\n" +
            "  gl_Position = uVP * vec4(p.x, uY, p.y, 1.0);\n" +
            "}\n";

    private static final String GROUND_FS =
            "#version 300 es\n" +
            "precision highp float;\n" +
            "uniform vec3 uColor;\n" +
            "uniform vec3 uFog;\n" +
            "uniform vec3 uEye;\n" +
            "in vec2 vXZ;\n" +
            "out vec4 outColor;\n" +
            "void main(){\n" +
            "  float d = distance(vec3(vXZ.x, 0.0, vXZ.y), uEye);\n" +
            "  float fog = clamp((d - 14.0) / 12.0, 0.0, 1.0);\n" +   // cùng công thức với cỏ
            "  outColor = vec4(mix(uColor, uFog, fog), 1.0);\n" +
            "}\n";

    // Tâm ngắm dấu cộng kiểu Minecraft: vẽ màu đảo ngược so với nền nên thấy rõ cả trên trời trắng lẫn cỏ
    private static final String CROSS_VS =
            "#version 300 es\n" +
            "uniform vec2 uOff;\n" +
            "uniform vec2 uHalf;\n" +
            "void main(){\n" +
            "  vec2 c = vec2(float(gl_VertexID & 1) * 2.0 - 1.0, float((gl_VertexID >> 1) & 1) * 2.0 - 1.0);\n" +
            "  gl_Position = vec4(uOff + c * uHalf, 0.0, 1.0);\n" +
            "}\n";

    private static final String CROSS_FS =
            "#version 300 es\n" +
            "precision mediump float;\n" +
            "out vec4 outColor;\n" +
            "void main(){ outColor = vec4(1.0); }\n";

    private static final String FS =
            "#version 300 es\n" +
            "precision mediump float;\n" +
            "uniform sampler2D uTex;\n" +
            "uniform vec3 uFogColor;\n" +
            "in vec2 vUV;\n" +
            "in float vFog;\n" +
            "out vec4 outColor;\n" +
            "void main(){\n" +
            "  vec3 c = texture(uTex, vUV).rgb;\n" +
            "  outColor = vec4(mix(c, uFogColor, vFog), 1.0);\n" +
            "}\n";

    private final Context context;
    private int groundProgram, crossProgram;
    private int viewW = 1, viewH = 1;
    private final float density;
    private int program, vao, indexCount, grassTex, windTex, instVbo;
    private int uVP, uEye, uTime, uWind, uTex, uFogColor;
    private final java.nio.FloatBuffer instBuf =
            ByteBuffer.allocateDirect(SIDE * SIDE * 8).order(ByteOrder.nativeOrder()).asFloatBuffer();
    private final float[] proj = new float[16];
    private final float[] view = new float[16];
    private final float[] vp = new float[16];
    private float aspect = 1f;
    private long startNs;

    // Camera tự do: vị trí trên mặt phẳng + góc quay (độ). yaw=0 nhìn về -z, pitch<0 nhìn xuống.
    private volatile float moveStrafe = 0f, moveForward = 0f;
    private long lastNs;
    private volatile boolean sneak = false, jumpHeld = false;
    private float posY = 0f, velY = 0f, eyeCur = EYE_STAND;
    private volatile float posX = 0f, posZ = 0f, yaw = 0f, pitch = -10f;

    public GrassRenderer(Context context) {
        this.context = context.getApplicationContext();
        this.density = context.getResources().getDisplayMetrics().density;
    }

    /** strafe: -1 trái..+1 phải; forward: -1 lùi..+1 tiến (từ các nút điều khiển). */
    public void setMove(float strafe, float forward) {
        moveStrafe = strafe;
        moveForward = forward;
    }

    public void setSneak(boolean on) {
        sneak = on;
    }

    /** true khi đang giữ nút nhảy (giữ thì nhảy liên tục khi chạm đất). */
    public void setJump(boolean held) {
        jumpHeld = held;
    }

    /** Xoay camera: kéo sang phải = quay phải, kéo lên = ngước lên. */
    public void look(float dx, float dy) {
        yaw = (yaw + dx * 0.2f) % 360f;
        pitch = Math.max(-89f, Math.min(89f, pitch - dy * 0.2f));
    }

    @Override
    public void onSurfaceCreated(GL10 unused, EGLConfig config) {
        GLES30.glClearColor(SKY_R, SKY_G, SKY_B, 1f); // trời trắng
        GLES30.glEnable(GLES30.GL_DEPTH_TEST);
        GLES30.glDisable(GLES30.GL_CULL_FACE); // lá cỏ hai mặt (doubleSided)

        program = link(compile(GLES30.GL_VERTEX_SHADER, VS), compile(GLES30.GL_FRAGMENT_SHADER, FS));
        crossProgram = link(compile(GLES30.GL_VERTEX_SHADER, CROSS_VS), compile(GLES30.GL_FRAGMENT_SHADER, CROSS_FS));
        groundProgram = link(compile(GLES30.GL_VERTEX_SHADER, GROUND_VS), compile(GLES30.GL_FRAGMENT_SHADER, GROUND_FS));
        uVP = GLES30.glGetUniformLocation(program, "uVP");
        uEye = GLES30.glGetUniformLocation(program, "uEye");
        uTime = GLES30.glGetUniformLocation(program, "uTime");
        uWind = GLES30.glGetUniformLocation(program, "uWind");
        uTex = GLES30.glGetUniformLocation(program, "uTex");
        uFogColor = GLES30.glGetUniformLocation(program, "uFogColor");

        loadMesh();
        grassTex = loadGrassTexture();
        startNs = System.nanoTime();
        lastNs = startNs;
    }

    @Override
    public void onSurfaceChanged(GL10 unused, int width, int height) {
        GLES30.glViewport(0, 0, width, height);
        aspect = (float) width / Math.max(1, height);
        viewW = Math.max(1, width);
        viewH = Math.max(1, height);
    }

    @Override
    public void onDrawFrame(GL10 unused) {
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT | GLES30.GL_DEPTH_BUFFER_BIT);

        long nowNs = System.nanoTime();
        float dt = Math.min((nowNs - lastNs) / 1e9f, 0.1f);
        lastNs = nowNs;
        float ms = moveStrafe, mf = moveForward;
        float ml = (float) Math.sqrt(ms * ms + mf * mf);
        float walk = WALK_SPEED * (sneak ? SNEAK_SPEED : 1f);
        if (ml > 0f) {
            ms /= ml;
            mf /= ml;
            double y = Math.toRadians(yaw);
            posX += ((float) Math.sin(y) * mf + (float) Math.cos(y) * ms) * walk * dt;
            posZ += ((float) -Math.cos(y) * mf + (float) Math.sin(y) * ms) * walk * dt;
        }

        // nhảy: trọng lực đơn giản, mặt đất y = 0
        if (jumpHeld && posY <= 0f && velY == 0f) velY = JUMP_V;
        if (posY > 0f || velY > 0f) {
            velY -= GRAVITY * dt;
            posY += velY * dt;
            if (posY <= 0f) { posY = 0f; velY = 0f; }
        }
        // ngồi: hạ mắt xuống mượt
        float eyeTarget = sneak ? EYE_SNEAK : EYE_STAND;
        eyeCur += (eyeTarget - eyeCur) * Math.min(1f, dt * 12f);

        float cx = posX, cz = posZ, yw = yaw, pt = pitch;
        double yr = Math.toRadians(yw), pr = Math.toRadians(pt);
        float cp = (float) Math.cos(pr);
        float dirX = (float) Math.sin(yr) * cp, dirY = (float) Math.sin(pr), dirZ = (float) -Math.cos(yr) * cp;
        float ey = posY + eyeCur;
        Matrix.perspectiveM(proj, 0, FOV, aspect, 0.2f, 5000f);
        Matrix.setLookAtM(view, 0, cx, ey, cz, cx + dirX, ey + dirY, cz + dirZ, 0f, 1f, 0f);
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0);
        drawGround(cx, ey, cz);

        // Chỉ vẽ các ô cỏ trong tầm nhìn: vòng tròn bán kính R và nằm trong hình quạt hướng nhìn
        float fx = (float) Math.sin(yr), fz = (float) -Math.cos(yr);
        double halfH = Math.toDegrees(Math.atan(aspect * Math.tan(Math.toRadians(FOV / 2f)))) + 15.0;
        float cosLim = halfH >= 180.0 ? -1f : (float) Math.cos(Math.toRadians(halfH));
        int bx = (int) Math.floor(cx) - R, bz = (int) Math.floor(cz) - R;
        instBuf.clear();
        int n = 0;
        for (int i = 0; i < SIDE; i++) {
            for (int j = 0; j < SIDE; j++) {
                float tx = bx + i, tz = bz + j;
                float dx = tx + 0.5f - cx, dz = tz + 0.5f - cz;
                float d2 = dx * dx + dz * dz;
                if (d2 > (float) R * R) continue;
                if (d2 > NEAR_R * NEAR_R && dx * fx + dz * fz < cosLim * (float) Math.sqrt(d2)) continue;
                instBuf.put(tx).put(tz);
                n++;
            }
        }
        instBuf.position(0);

        float elapsed = (System.nanoTime() - startNs) / 1e9f;

        GLES30.glUseProgram(program);
        GLES30.glUniformMatrix4fv(uVP, 1, false, vp, 0);
        GLES30.glUniform3f(uEye, cx, ey, cz);
        GLES30.glUniform1f(uTime, elapsed % 12f);
        GLES30.glUniform3f(uFogColor, SKY_R, SKY_G, SKY_B);

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, instVbo);
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, n * 8, instBuf, GLES30.GL_DYNAMIC_DRAW);

        GLES30.glActiveTexture(GLES30.GL_TEXTURE0);
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, grassTex);
        GLES30.glUniform1i(uTex, 0);
        GLES30.glActiveTexture(GLES30.GL_TEXTURE1);
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, windTex);
        GLES30.glUniform1i(uWind, 1);

        GLES30.glBindVertexArray(vao);
        if (n > 0) {
            GLES30.glDrawElementsInstanced(GLES30.GL_TRIANGLES, indexCount,
                    GLES30.GL_UNSIGNED_SHORT, 0, n);
        }
        GLES30.glBindVertexArray(0);
        drawCrosshair();
    }

    /** Dấu cộng ở giữa màn hình, màu đảo ngược nền. Ba hình chữ nhật không chồng nhau để tâm không bị lõm. */
    private void drawCrosshair() {
        float t = Math.max(1.5f, 0.75f * density);   // nửa độ dày (px)
        float l = 9f * density;                      // nửa chiều dài mỗi tay (px)
        float kx = 2f / viewW, ky = 2f / viewH;      // px -> NDC

        GLES30.glDisable(GLES30.GL_DEPTH_TEST);
        GLES30.glEnable(GLES30.GL_BLEND);
        GLES30.glBlendFunc(GLES30.GL_ONE_MINUS_DST_COLOR, GLES30.GL_ONE_MINUS_SRC_COLOR);
        GLES30.glUseProgram(crossProgram);
        int uOff = GLES30.glGetUniformLocation(crossProgram, "uOff");
        int uHalf = GLES30.glGetUniformLocation(crossProgram, "uHalf");
        // thanh ngang
        GLES30.glUniform2f(uOff, 0f, 0f);
        GLES30.glUniform2f(uHalf, l * kx, t * ky);
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4);
        // hai đoạn dọc (trên, dưới), bỏ phần giữa đã được thanh ngang phủ
        float segHalf = (l - t) / 2f, segCenter = (l + t) / 2f;
        GLES30.glUniform2f(uHalf, t * kx, segHalf * ky);
        GLES30.glUniform2f(uOff, 0f, segCenter * ky);
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4);
        GLES30.glUniform2f(uOff, 0f, -segCenter * ky);
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4);

        GLES30.glDisable(GLES30.GL_BLEND);
        GLES30.glEnable(GLES30.GL_DEPTH_TEST);
    }

    /** Vẽ mặt đất xanh lá đậm (hình học thật, có depth). Phía trên chân trời là trời trắng (màu clear). */
    private void drawGround(float cx, float ey, float cz) {
        GLES30.glUseProgram(groundProgram);
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(groundProgram, "uVP"), 1, false, vp, 0);
        GLES30.glUniform2f(GLES30.glGetUniformLocation(groundProgram, "uCenter"), cx, cz);
        GLES30.glUniform1f(GLES30.glGetUniformLocation(groundProgram, "uSize"), 20000f);
        GLES30.glUniform1f(GLES30.glGetUniformLocation(groundProgram, "uY"), -0.01f);
        GLES30.glUniform3f(GLES30.glGetUniformLocation(groundProgram, "uColor"), GR, GG, GB);
        GLES30.glUniform3f(GLES30.glGetUniformLocation(groundProgram, "uFog"), SKY_R, SKY_G, SKY_B);
        GLES30.glUniform3f(GLES30.glGetUniformLocation(groundProgram, "uEye"), cx, ey, cz);
        GLES30.glBindVertexArray(0);
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4);
    }

    // ---------- tải model (grass.bin tạo từ GLB bằng tools/convert_glb.py) ----------

    private void loadMesh() {
        try (InputStream in = context.getAssets().open("grass.bin")) {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            byte[] data = bos.toByteArray();

            ByteBuffer head = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
            if (head.getInt(0) != 0x32535247) throw new RuntimeException("grass.bin sai định dạng"); // 'GRS2'
            int nV = head.getInt(4), nI = head.getInt(8), nBlades = head.getInt(12), nSamples = head.getInt(16);
            int off = 20;

            ByteBuffer vb = ByteBuffer.allocateDirect(nV * STRIDE).order(ByteOrder.nativeOrder());
            ByteBuffer ib = ByteBuffer.allocateDirect(nI * 2).order(ByteOrder.nativeOrder());
            ByteBuffer wb = ByteBuffer.allocateDirect(nBlades * nSamples * 4).order(ByteOrder.nativeOrder());
            // Chép từng giá trị theo little-endian để đúng trên mọi máy
            for (int i = 0; i < nV * 9; i++) vb.putFloat(head.getFloat(off + i * 4));
            off += nV * STRIDE;
            for (int i = 0; i < nI; i++) ib.putShort(head.getShort(off + i * 2));
            off += nI * 2;
            for (int i = 0; i < nBlades * nSamples; i++) wb.putFloat(head.getFloat(off + i * 4));
            vb.position(0); ib.position(0); wb.position(0);
            indexCount = nI;

            int[] a = new int[4];
            GLES30.glGenVertexArrays(1, a, 0);
            vao = a[0];
            GLES30.glBindVertexArray(vao);
            GLES30.glGenBuffers(3, a, 1);
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, a[1]);
            GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, nV * STRIDE, vb, GLES30.GL_STATIC_DRAW);
            GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, a[2]);
            GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER, nI * 2, ib, GLES30.GL_STATIC_DRAW);
            GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, STRIDE, 0);
            GLES30.glVertexAttribPointer(1, 2, GLES30.GL_FLOAT, false, STRIDE, 12);
            GLES30.glVertexAttribPointer(2, 3, GLES30.GL_FLOAT, false, STRIDE, 20);
            GLES30.glVertexAttribPointer(3, 1, GLES30.GL_FLOAT, false, STRIDE, 32);
            for (int i = 0; i < 4; i++) GLES30.glEnableVertexAttribArray(i);
            instVbo = a[3];
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, instVbo);
            GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, SIDE * SIDE * 8, null, GLES30.GL_DYNAMIC_DRAW);
            GLES30.glVertexAttribPointer(4, 2, GLES30.GL_FLOAT, false, 8, 0);
            GLES30.glEnableVertexAttribArray(4);
            GLES30.glVertexAttribDivisor(4, 1);
            GLES30.glBindVertexArray(0);

            // Texture trọng số gió: rộng = số mẫu thời gian, cao = số lá cỏ
            int[] t = new int[1];
            GLES30.glGenTextures(1, t, 0);
            windTex = t[0];
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, windTex);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_NEAREST);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_NEAREST);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE);
            GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 4);
            GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_R32F, nSamples, nBlades, 0,
                    GLES30.GL_RED, GLES30.GL_FLOAT, wb);
        } catch (java.io.IOException e) {
            throw new RuntimeException(e);
        }
    }

    private int loadGrassTexture() {
        try (InputStream in = context.getAssets().open("grass.png")) {
            Bitmap bmp = BitmapFactory.decodeStream(in);
            int[] t = new int[1];
            GLES30.glGenTextures(1, t, 0);
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, t[0]);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_NEAREST);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_NEAREST);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE);
            GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bmp, 0);
            bmp.recycle();
            return t[0];
        } catch (java.io.IOException e) {
            throw new RuntimeException(e);
        }
    }

    // ---------- shader ----------

    private static int compile(int type, String src) {
        int s = GLES30.glCreateShader(type);
        GLES30.glShaderSource(s, src);
        GLES30.glCompileShader(s);
        int[] ok = new int[1];
        GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, ok, 0);
        if (ok[0] == 0) {
            String log = GLES30.glGetShaderInfoLog(s);
            GLES30.glDeleteShader(s);
            throw new RuntimeException("Shader lỗi: " + log);
        }
        return s;
    }

    private static int link(int vs, int fs) {
        int p = GLES30.glCreateProgram();
        GLES30.glAttachShader(p, vs);
        GLES30.glAttachShader(p, fs);
        GLES30.glLinkProgram(p);
        int[] ok = new int[1];
        GLES30.glGetProgramiv(p, GLES30.GL_LINK_STATUS, ok, 0);
        if (ok[0] == 0) throw new RuntimeException("Link lỗi: " + GLES30.glGetProgramInfoLog(p));
        return p;
    }
}
