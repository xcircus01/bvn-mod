package com.example.greenfield;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.view.MotionEvent;

/**
 * Điều khiển hai vùng (có thể dùng đồng thời):
 *  - Nửa màn hình bên trái: kéo để di chuyển.
 *  - Nửa màn hình bên phải: kéo để xoay camera (trái/phải/sau, ngước lên/nhìn xuống).
 */
public class GameView extends GLSurfaceView {
    private static final int MAX = 16;
    private static final int NONE = 0, MOVE = 1, LOOK = 2;

    private final GrassRenderer renderer;
    private final int[] role = new int[MAX];
    private final float[] lastX = new float[MAX], lastY = new float[MAX];

    public GameView(Context context) {
        super(context);
        setEGLContextClientVersion(3);
        setEGLConfigChooser(8, 8, 8, 8, 16, 0);
        renderer = new GrassRenderer(context);
        setRenderer(renderer);
        setRenderMode(RENDERMODE_CONTINUOUSLY);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN: {
                int i = e.getActionIndex();
                int id = e.getPointerId(i);
                if (id < MAX) {
                    role[id] = e.getX(i) < getWidth() / 2f ? MOVE : LOOK;
                    lastX[id] = e.getX(i);
                    lastY[id] = e.getY(i);
                }
                break;
            }
            case MotionEvent.ACTION_MOVE:
                for (int i = 0; i < e.getPointerCount(); i++) {
                    int id = e.getPointerId(i);
                    if (id >= MAX || role[id] == NONE) continue;
                    float dx = e.getX(i) - lastX[id], dy = e.getY(i) - lastY[id];
                    lastX[id] = e.getX(i);
                    lastY[id] = e.getY(i);
                    if (role[id] == MOVE) renderer.move(dx, dy);
                    else renderer.look(dx, dy);
                }
                break;
            case MotionEvent.ACTION_POINTER_UP: {
                int id = e.getPointerId(e.getActionIndex());
                if (id < MAX) role[id] = NONE;
                break;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                java.util.Arrays.fill(role, NONE);
                break;
        }
        return true;
    }

    public void resume() { onResume(); }

    public void pause() { onPause(); }
}
